package com.testapp1.ns.cameraapp;


public class Case {
    int id;
    int doctorId;
    int patientId;

    String caseCreationTS;
    String caseUpdationTS;
    String PatientName;
    String caseDesc;
    String caseName;
    String docComments;
    String patientComments;
    String caseStatus;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(int doctorId) {
        this.doctorId = doctorId;
    }

    public int getPatientId() {
        return patientId;
    }

    public void setPatientId(int patientId) {
        this.patientId = patientId;
    }

    public String getCaseDesc() {
        return caseDesc;
    }

    public void setCaseDesc(String caseDesc) {
        this.caseDesc = caseDesc;
    }

    public String getCaseName() {
        return caseName;
    }

    public void setCaseName(String caseName) {
        this.caseName = caseName;
    }

    public String getDocComments() {
        return docComments;
    }

    public void setDocComments(String docComments) {
        this.docComments = docComments;
    }

    public String getPatientComments() {
        return patientComments;
    }

    public void setPatientComments(String patientComments) {
        this.patientComments = patientComments;
    }

    public String getCaseStatus() {
        return caseStatus;
    }

    public void setCaseStatus(String caseStatus) {
        this.caseStatus = caseStatus;
    }

    public String getCaseCreationTS() {
        return caseCreationTS;
    }

    public void setCaseCreationTS(String caseCreationTS) {
        this.caseCreationTS = caseCreationTS;
    }

    public String getCaseUpdationTS() {
        return caseUpdationTS;
    }

    public void setCaseUpdationTS(String caseUpdationTS) {
        this.caseUpdationTS = caseUpdationTS;
    }
    public int getPhoto() {
        return R.drawable.ic_person;
    }
    public String getPatientName() {
        return PatientName;
    }

    public void setPatientName(String patientName) {
        PatientName = patientName;
    }



}

package com.testapp1.ns.cameraapp;

        import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
public class MyCasehistoryAdaptor extends RecyclerView
.Adapter<MyCasehistoryAdaptor
.DatachObjectHolder>  {
    ArrayList<Case> mDataSet;
   public MyCasehistoryAdaptor(ArrayList<Case> mDataSet)
   {
       this.mDataSet=mDataSet;
   }
    public static class DatachObjectHolder extends RecyclerView.ViewHolder
            implements View
            .OnClickListener {
        TextView case_id;
        TextView Doctor_id;
        TextView case_name;
        TextView patient_id;
        TextView case_status;
        TextView update_time;



        @Override
        public void onClick(View v) {

        }



        public DatachObjectHolder(View itemView) {
            super(itemView);
            case_id = (TextView) itemView.findViewById(R.id.case_id);
            Doctor_id = (TextView) itemView.findViewById(R.id.Doctor_id);
            case_name=(TextView)itemView.findViewById(R.id.Case_name);
            patient_id = (TextView) itemView.findViewById(R.id.Patient_id);
            case_status = (TextView) itemView.findViewById(R.id.Case_status);
            update_time=(TextView) itemView.findViewById(R.id.updated_time);

            itemView.setOnClickListener(this);
        }
    }
    @Override
    public MyCasehistoryAdaptor.DatachObjectHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.card_casehistory, parent, false);

        DatachObjectHolder datachObjectHolder = new DatachObjectHolder(view);
        return datachObjectHolder;

    }

    @Override
    public void onBindViewHolder(MyCasehistoryAdaptor.DatachObjectHolder holder, int position) {
        holder.case_id.setText(mDataSet.get(position).getId()+"");
        holder.Doctor_id.setText(mDataSet.get(position).getDoctorId()+"");
        holder.case_name.setText(mDataSet.get(position).getCaseName()+"");
        holder.patient_id.setText(mDataSet.get(position).getPatientId()+"");
        holder.case_status.setText(mDataSet.get(position).getCaseStatus()+"");
        holder.update_time.setText(mDataSet.get(position).getCaseUpdationTS()+"");
    }

    @Override
    public int getItemCount() {
        return mDataSet.size();
    }
}

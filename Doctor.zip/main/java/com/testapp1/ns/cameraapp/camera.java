package com.testapp1.ns.cameraapp;

import android.app.Activity;
import android.content.IntentSender;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Parcel;
import android.provider.MediaStore;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.content.Intent;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.security.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

public class camera extends AppCompatActivity  {
    Button btn;
    ImageView imgview;
    private static Bitmap imgFile;
    private static final String TAG = "drive-quickstart";
    private static final int REQUEST_CODE_CAPTURE_IMAGE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera);
        //mapping with UI Elements
        btn = (Button) findViewById(R.id.button);
        imgview = (ImageView) findViewById(R.id.imageView);


    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case REQUEST_CODE_CAPTURE_IMAGE:
                // Called after a photo has been taken.
                if (resultCode == Activity.RESULT_OK) {
                    // Store the image data as a bitmap for writing later.
                    this.imgFile = (Bitmap) data.getExtras().get("data");
                    imgview.setImageBitmap(this.imgFile);
                }
                break;

        }
    }

    public void cam_click(View v) {
        Intent capture_picture=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
        String fname="profile_pic_"+timeStamp+".jpg";
        // this.imgFile= new File(Environment.getExternalStorageDirectory(),fname);
        // Uri imgUri= Uri.fromFile(imgFile);
        //capture_picture.putExtra(MediaStore.EXTRA_OUTPUT,imgUri);
        // capture_picture.putExtra(MediaStore.EXTRA_VIDEO_QUALITY, 0.5);
        if(capture_picture.resolveActivity(getPackageManager())!=null) {
            startActivityForResult(capture_picture,REQUEST_CODE_CAPTURE_IMAGE);
        }

    }
    public  void btnCall_click(View v)
    {
        EditText phNumber=(EditText)findViewById(R.id.phnumber);
        String telNum=phNumber.getText().toString();
        Intent callerIntent=new Intent(Intent.ACTION_DIAL,Uri.fromParts("tel", telNum, null));
        startActivity(callerIntent);
    }

    public void btnMsg_Click(View v)
    {
        EditText phNumber=(EditText)findViewById(R.id.phnumber);
        String telNum=phNumber.getText().toString();
        Intent intentsms = new Intent( Intent.ACTION_VIEW, Uri.parse( "sms:" + telNum ) );
        intentsms.putExtra( "sms_body", "Please enter your message here" );
        startActivity( intentsms );
    }

}

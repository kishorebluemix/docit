package com.testapp1.ns.cameraapp;

import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class case_history_view extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_case_history_view);
        try {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);

            String requestUrl="https://docit.tcs.us-south.mybluemix.net/api/case?doctorId="+ DoctorInfo.docId +"&status=CLOSED";
            URL url = new URL(requestUrl);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            String readStream = readStream(con.getInputStream());
            ArrayList<Case> crd_history=CardViewActivity.parseJSON(readStream);
            if(crd_history != null) {
                mRecyclerView = (RecyclerView) findViewById(R.id.case_recycler_view);
                mRecyclerView.setHasFixedSize(false);
                mLayoutManager = new LinearLayoutManager(this);
                mRecyclerView.setLayoutManager(mLayoutManager);
                mAdapter = new MyCasehistoryAdaptor(crd_history);
                mRecyclerView.setAdapter(mAdapter);
                mRecyclerView.setPadding(5, 5, 5, 5);
            }
            else
            {
                Toast.makeText(getApplicationContext(), "No history cases for doctor", Toast.LENGTH_LONG);
            }

        } catch (Exception e) {
            System.out.println("ERROR : " + e.getMessage());

        }

    }

    private static String readStream(InputStream in) {
        StringBuilder sb = new StringBuilder();
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));

            String nextLine = "";
            while ((nextLine = reader.readLine()) != null) {
                sb.append(nextLine);

            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {

        }
        return sb.toString();
    }
    private ArrayList<DAOCasehistory> getDataSet() {
        ArrayList results = new ArrayList<DataObject>();
        //TODO add image string from db to replace image
        for (int index = 0; index < 20; index++) {
           DAOCasehistory obj = new DAOCasehistory("Case_id  " + index,
                    "Doctor_id" + index,"case Name :health issues "+index,"Patient_id"+index ,"case_status" +index,"update_time"+index);
            results.add(index, obj);
        }
        return results;
    }

}

package com.testapp1.ns.cameraapp;

public class DAOCaseFileId {
    private int fileId;

}

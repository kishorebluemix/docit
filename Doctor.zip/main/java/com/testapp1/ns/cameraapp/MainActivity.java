package com.testapp1.ns.cameraapp;

import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
Button clickButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
clickButton=(Button) findViewById(R.id.button2);
        clickButton.setOnClickListener(this);
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

    @Override
    public void onClick(View v) {
        EditText loginName = (EditText) findViewById(R.id.login);
        EditText password = (EditText) findViewById(R.id.password);
        if (checkUser(loginName.getText().toString(), password.getText().toString())) {
            startActivity(new Intent(this, TabsActivity.class));
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
     public boolean checkUser(String login,String password)
    {

        try {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            String url="https://docit.tcs.us-south.mybluemix.net/api/Doctor?docEmail="+login;
            URL urlConnection = new URL(url);
            HttpURLConnection con = (HttpURLConnection) urlConnection.openConnection();

            String ret = readStream(con.getInputStream());
            if (null != ret && ret.length() > 0 && password.equals("123")) {
                // Case casee[] = (Case[])JSONParser.parseJson(Case[].class);
                Gson gson = new Gson();

                DoctorObj docinf[] = (DoctorObj[]) gson.fromJson(ret, DoctorObj[].class);
                DoctorInfo.docPhoto = BitmapFactory.decodeResource(getResources(), R.drawable.ic_person);
                DoctorInfo.docId=docinf[0].getId();
                DoctorInfo.docEmail=docinf[0].getDocEmail();
                DoctorInfo.docName=docinf[0].getDocName();
                DoctorInfo.docAddress=docinf[0].getDocClinicAddress();
                DoctorInfo.docDob=docinf[0].getDocDOB();
                DoctorInfo.docEdu=docinf[0].getDocEdu();
                DoctorInfo.docExp=docinf[0].getDocExp();
                DoctorInfo.dochignlights=docinf[0].getDocHighlights();
                DoctorInfo.docSpec=docinf[0].getDocMajSpec();
                DoctorInfo.docPhone=docinf[0].getDocPhone();
                DoctorInfo.docSex=docinf[0].getDocSex();

                return  true;


            }

        } catch (Exception e) {
            e.printStackTrace();
        }


        return false;
    }
    private static String readStream(InputStream in) {
        StringBuilder sb = new StringBuilder();
        try
        {
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));

            String nextLine = "";
            while ((nextLine = reader.readLine()) != null) {
                sb.append(nextLine);

            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        finally {

        }
        return sb.toString();
    }
}

package com.testapp1.ns.cameraapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class DoctorProfile extends AppCompatActivity {
    ImageButton MyProfile;
    TextView docName;
    TextView docId;
    TextView specialization;
    TextView docEmail;
    ImageView docPic;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_profile);

        docPic=(ImageView) findViewById(R.id.imgDoc);
        if(DoctorInfo.docPhoto ==null) {
            docPic.setImageResource(R.drawable.ic_person);
        }
        else {
            docPic.setImageBitmap(DoctorInfo.docPhoto);
        }
        docName=(TextView) findViewById(R.id.docname);
        docId=(TextView) findViewById(R.id.docId);
        docEmail=(TextView) findViewById(R.id.docEmail);
        specialization=(TextView) findViewById(R.id.docSpecialization);
        docName.setText(DoctorInfo.docName);
        docId.setText(DoctorInfo.docId);
        docEmail.setText(DoctorInfo.docEmail);
        specialization.setText(DoctorInfo.docSpec);

    }

    public void btnEdit_Click(View v)
    {
        startActivity(new Intent(this, EditProfile.class));
    }

}


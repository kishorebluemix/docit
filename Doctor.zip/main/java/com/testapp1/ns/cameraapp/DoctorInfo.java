package com.testapp1.ns.cameraapp;

import android.graphics.Bitmap;

public  class DoctorInfo
{

    public static Bitmap docPhoto;
    public static String docEmail;
    public static String docSpec;
    public static String docId;
    public static  String docName;
    public static  String docSex;
    public static  String docPhone;
    public static  String dochignlights;
    public static  String docAddress;
    public static  String docDob;
    public static String docExp;
    public static String docEdu;

}

package com.testapp1.ns.cameraapp;

public class DataObject {
    public String getPersonName() {
        return personName;
    }

    public void setPersonName(String personName) {
        this.personName = personName;
    }

    public String getCaseId() {
        return caseId;
    }

    public void setCaseId(String caseId) {
        this.caseId = caseId;
    }

    public String getCaseSummary() {
        return caseSummary;
    }

    public void setCaseSummary(String caseSummary) {
        this.caseSummary = caseSummary;
    }

    public String getCaseStatus() {
        return caseStatus;
    }

    public void setCaseStatus(String caseStatus) {
        this.caseStatus = caseStatus;
    }

    public String getCaseDate() {
        return caseDate;
    }

    public void setCaseDate(String caseDate) {
        this.caseDate = caseDate;
    }

    private String personName;
    private String caseId;
    private String caseSummary;
    private String caseStatus;
    private String caseDate;


//TODO set this to image type for image
    public int getPhoto() {
        return R.drawable.ic_person;
    }


    DataObject (String personName, String caseId,String caseSummary,String caseStatus,String caseDate){
        this.personName=personName;
        this.caseId=caseId;
        this.caseSummary=caseSummary;
        this.caseStatus=caseStatus;
        this.caseDate=caseDate;

    }


}

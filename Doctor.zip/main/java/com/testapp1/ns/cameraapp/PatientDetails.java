package com.testapp1.ns.cameraapp;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class PatientDetails extends AppCompatActivity {
    static ImageView imgAttach1;
    static ImageView imgAttach2;
    static ImageView imgAttach3;
    public static String pissue;
    private boolean zoomOut = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_details);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Bundle pDetails = this.getIntent().getExtras();
        TextView PatientId=(TextView)findViewById(R.id.Patient_id);
        TextView patientName = (TextView) findViewById(R.id.patient_name);
        TextView patientIssue = (TextView) findViewById(R.id.patient_comments);
        TextView case_name=(TextView) findViewById(R.id.patient_name);
        TextView case_desc=(TextView) findViewById(R.id.caseDescription);
        EditText doc_comments=(EditText) findViewById(R.id.docComments);

        //TextView CaseDesc=(TextView)findViewById(R.id.);
        imgAttach1 = (ImageView) findViewById(R.id.imgAttach1);
        imgAttach2 = (ImageView) findViewById(R.id.imgAttach2);
        imgAttach3 = (ImageView) findViewById(R.id.imgAttach3);
        imgAttach1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (zoomOut) {
                    imgAttach1.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
                    imgAttach1.setAdjustViewBounds(true);
                    zoomOut = false;
                } else {
                    imgAttach1.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));
                    imgAttach1.setScaleType(ImageView.ScaleType.FIT_XY);
                    zoomOut = true;
                }
            }
        });

        imgAttach2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (zoomOut) {
                    imgAttach2.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
                    imgAttach2.setAdjustViewBounds(true);
                    zoomOut = false;
                } else {
                    imgAttach2.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));
                    imgAttach2.setScaleType(ImageView.ScaleType.FIT_XY);
                    zoomOut = true;
                }
            }
        });

        imgAttach3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (zoomOut) {
                    imgAttach3.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
                    imgAttach3.setAdjustViewBounds(true);
                    zoomOut = false;
                } else {
                    imgAttach3.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));
                    imgAttach3.setScaleType(ImageView.ScaleType.FIT_XY);
                    zoomOut = true;
                }
            }
        });
        try {

            String pid=pDetails.getString("pName");
            pissue = pDetails.getString("pIssue");
            String pcomment = pDetails.getString("PatientComments");
            String caseName=pDetails.getString("caseName");
            String caseDesc=pDetails.getString("caseDesc");
            String docComments=pDetails.getString("docComments");
            String caseTs=pDetails.getString("caseTs");

            PatientId.setText(pid);
            patientIssue.setText(pcomment);
            case_name.setText(caseName);
            case_desc.setText(caseDesc);
            doc_comments.setText(docComments);

            new ImageLoadTask().execute(pissue);
        } catch (Exception ec) {

        }
    }

    public void btnUpdateComment(View v) {
        String requesturl = "https://docit.tcs.us-south.mybluemix.net/api/case/caseId=" + pissue;
        try
        {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        URL urlConnection = new URL(requesturl);
        HttpURLConnection httpCon = (HttpURLConnection) urlConnection.openConnection();
        httpCon.setDoOutput(true);
        httpCon.setRequestMethod("PUT");
            httpCon.setRequestProperty("Content-type", "multipart/form-data");
            httpCon.setDoOutput(true);
            httpCon.setDoInput(true);

            OutputStreamWriter out = new OutputStreamWriter(
                httpCon.getOutputStream());
        out.write("Resource content");
        out.close();

    }

    catch(IOException e)
    {
        e.printStackTrace();
    }

}

    public static void setAttachment(ArrayList<Bitmap> bmpArr)
    {
        for(int i=0;i<bmpArr.size();i++)
        {
            switch (i)
            {
                case 0:
                    imgAttach1.setImageBitmap(bmpArr.get(i));
                    imgAttach1.setVisibility(View.VISIBLE);
                    break;
                case 1:
                    imgAttach2.setImageBitmap(bmpArr.get(i));
                    imgAttach2.setVisibility(View.VISIBLE);
                    break;
                case 2:
                    imgAttach3.setImageBitmap(bmpArr.get(i));
                    imgAttach3.setVisibility(View.VISIBLE);
                    break;
            }

        }
    }

}
 class ImageLoadTask extends AsyncTask<String, Void,  ArrayList<Bitmap>> {

    private String url;
    private ImageView imageView;

    @Override
    protected  ArrayList<Bitmap> doInBackground(String... params) {
        ArrayList<Bitmap> bmpArr=new ArrayList<Bitmap>();
        try {
            url="https://docit.tcs.us-south.mybluemix.net/api/case/caseFileIds?caseId="+params[0];
            URL urlConnection = new URL(url);
            HttpURLConnection con = (HttpURLConnection) urlConnection.openConnection();

            String readStream = readStream(con.getInputStream());
            if (null != readStream && readStream.length() > 0) {
                // Case casee[] = (Case[])JSONParser.parseJson(Case[].class);
                Gson gson = new Gson();

                String casee[] = (String[]) gson.fromJson(readStream, String[].class);
                for (int i = 0; i < casee.length; i++) {
                    url="https://docit.tcs.us-south.mybluemix.net/api/case/image?caseFileId="+Integer.parseInt(casee[i]);
                     urlConnection = new URL(url);
                    con = (HttpURLConnection) urlConnection.openConnection();
                    InputStream input = con.getInputStream();
                    Bitmap myBitmap = BitmapFactory.decodeStream(input);
                    bmpArr.add(myBitmap);
                }
                return bmpArr;
            }

            return null;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bmpArr;
    }
     private static String readStream(InputStream in) {
         StringBuilder sb = new StringBuilder();
         try
         {
             BufferedReader reader = new BufferedReader(new InputStreamReader(in));

             String nextLine = "";
             while ((nextLine = reader.readLine()) != null) {
                 sb.append(nextLine);

             }
             reader.close();
         } catch (IOException e) {
             e.printStackTrace();
         }
         finally {

         }
         return sb.toString();
     }

    @Override
    protected void onPostExecute(ArrayList<Bitmap> result) {
        PatientDetails.setAttachment(result);
    }

}

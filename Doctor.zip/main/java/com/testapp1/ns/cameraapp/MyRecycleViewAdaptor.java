package com.testapp1.ns.cameraapp;

import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;



public class MyRecycleViewAdaptor extends RecyclerView
        .Adapter<MyRecycleViewAdaptor
        .DataObjectHolder> {
    private static String LOG_TAG = "MyRecyclerViewAdapter";
    private ArrayList<Case> mDataset;
    private static MyClickListener myClickListener;

    public MyRecycleViewAdaptor() {

    }

    public static class DataObjectHolder extends RecyclerView.ViewHolder
            implements View
            .OnClickListener {
        TextView personName;
        TextView caseId;
        ImageView imv;
        TextView caseSummary;
        TextView caseStatus;
        TextView caseDate;
        TextView PatientComments;
        TextView patientId;

        public DataObjectHolder(View itemView) {
            super(itemView);
            personName = (TextView) itemView.findViewById(R.id.person_name);
            caseId = (TextView) itemView.findViewById(R.id.caseId);
            //imv=(ImageView)itemView.findViewById(R.id.person_photo);
            caseSummary = (TextView) itemView.findViewById(R.id.casesummary);
            caseStatus = (TextView) itemView.findViewById(R.id.casesatus);
            caseDate=(TextView) itemView.findViewById(R.id.casedate);
            Log.i(LOG_TAG, "Adding Listener");
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            myClickListener.onItemClick(getAdapterPosition(), v);
        }
    }

    public void setOnItemClickListener(MyClickListener myClickListener) {
        this.myClickListener = myClickListener;
    }

    public MyRecycleViewAdaptor(ArrayList<Case> myDataset) {
        mDataset = myDataset;
    }

    @Override
    public DataObjectHolder onCreateViewHolder(ViewGroup parent,
                                               int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.card_view, parent, false);

        DataObjectHolder dataObjectHolder = new DataObjectHolder(view);
        return dataObjectHolder;
    }

    @Override
    public void onBindViewHolder(DataObjectHolder holder, int position) {
        holder.personName.setText(mDataset.get(position).getPatientId()+"");
        holder.caseId.setText(mDataset.get(position).getId()+"");
        //holder.imv.setImageResource(mDataset.get(position).getPhoto());
        holder.caseSummary.setText(mDataset.get(position).getCaseDesc());
        holder.caseStatus.setText(mDataset.get(position).getCaseStatus());
        holder.caseDate.setText(mDataset.get(position).getCaseName());

    }

    public void addItem(Case dataObj, int index) {
        mDataset.add(index, dataObj);
        notifyItemInserted(index);
    }

    public void deleteItem(int index) {
        mDataset.remove(index);
        notifyItemRemoved(index);
    }

    @Override
    public int getItemCount() {
        return mDataset.size();
    }

    public interface MyClickListener {
        public void onItemClick(int position, View v);
    }
}
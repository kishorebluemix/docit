package com.testapp1.ns.cameraapp;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;

public class CardViewActivity extends AppCompatActivity {

    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    private String LOG_TAG = "CardViewActivity";
    public static  ArrayList<Case> crd_history;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card_view);

        try {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);

            String requestUrl="https://docit.tcs.us-south.mybluemix.net/api/case?doctorId="+ DoctorInfo.docId +"&status=OPEN";
            URL url = new URL(requestUrl);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            String readStream = readStream(con.getInputStream());
           ArrayList<Case> crd_history=CardViewActivity.parseJSON(readStream);
            if(crd_history != null) {
                mRecyclerView = (RecyclerView) findViewById(R.id.my_recycler_view);
                mRecyclerView.setHasFixedSize(false);
                mLayoutManager = new LinearLayoutManager(this);
                mRecyclerView.setLayoutManager(mLayoutManager);
                mAdapter = new MyRecycleViewAdaptor(crd_history);
                mRecyclerView.setAdapter(mAdapter);
                mRecyclerView.setPadding(5, 5, 5, 5);
            }
            else
            {
                Toast.makeText(getApplicationContext(),"No open cases for doctor",Toast.LENGTH_LONG);
            }

        } catch (Exception e) {
            System.out.println("ERROR : " + e.getMessage());

        }

        // Code to Add an item with default animation
        //((MyRecyclerViewAdapter) mAdapter).addItem(obj, index);

        // Code to remove an item with default animation
        //((MyRecyclerViewAdapter) mAdapter).deleteItem(index);
    }
    private static String readStream(InputStream in) {
        StringBuilder sb = new StringBuilder();
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));

            String nextLine = "";
            while ((nextLine = reader.readLine()) != null) {
                sb.append(nextLine);

            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {

        }
        return sb.toString();
    }

    public static ArrayList<Case> parseJSON(String result) {

        if (null != result && result.length() > 0) {
            // Case casee[] = (Case[])JSONParser.parseJson(Case[].class);
            Gson gson = new Gson();
            Case casee[] = (Case[]) gson.fromJson(result, Case[].class);
            crd_history = new ArrayList<Case>(Arrays.asList(casee));
            return crd_history;
        } else {
            return null;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        ((MyRecycleViewAdaptor) mAdapter).setOnItemClickListener(new MyRecycleViewAdaptor
                .MyClickListener() {
            @Override
            public void onItemClick(int position, View v) {
                Intent pDetails = new Intent(getApplicationContext(), PatientDetails.class);
                TextView patientName = (TextView) v.findViewById(R.id.person_name);
                TextView patientIssue = (TextView) v.findViewById(R.id.caseId);

                Bundle b = new Bundle();
                b.putString("pName", patientName.getText().toString());
                b.putString("pIssue", patientIssue.getText().toString());
                b.putString("patientCommemnts",CardViewActivity.crd_history.get(position).getPatientComments());
                b.putString("caseName",CardViewActivity.crd_history.get(position).getCaseName());
                b.putString("caseDesc",CardViewActivity.crd_history.get(position).getCaseDesc());
                b.putString("docComments",CardViewActivity.crd_history.get(position).getDocComments());
                b.putString("caseTs",CardViewActivity.crd_history.get(position).getCaseCreationTS());
                pDetails.putExtras(b);
                Log.i(LOG_TAG, " Clicked on Item " + patientName.getText().toString());
                startActivity(pDetails);
            }
        });
    }
}



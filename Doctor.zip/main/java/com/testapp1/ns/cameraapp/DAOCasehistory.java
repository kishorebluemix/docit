package com.testapp1.ns.cameraapp;

import android.widget.TextView;

/**
 * Created by Raghav on 16-02-2016.
 */
public class DAOCasehistory {
    public String case_id;
    public String doctor_id;
    public String case_name;
    public String patient_id;
    public String case_status;
    public String upadte_time;
public DAOCasehistory(String case_id,String doctor_id, String case_name, String patient_id, String case_status,
         String upadte_time)
{
    this.case_id=case_id;
    this.doctor_id=doctor_id;
    this.case_name=case_name;
    this.patient_id=patient_id;
    this.case_status=case_status;
    this.upadte_time=upadte_time;
}

    public String getCase_id() {
        return case_id;
    }

    public void setCase_id(String case_id) {
        this.case_id = case_id;
    }

    public String getDoctor_id() {
        return doctor_id;
    }

    public void setDoctor_id(String doctor_id) {
        this.doctor_id = doctor_id;
    }

    public String getCase_name() {
        return case_name;
    }

    public void setCase_name(String case_name) {
        this.case_name = case_name;
    }

    public String getPatient_id() {
        return patient_id;
    }

    public void setPatient_id(String patient_id) {
        this.patient_id = patient_id;
    }

    public String getCase_status() {
        return case_status;
    }

    public void setCase_status(String case_status) {
        this.case_status = case_status;
    }

    public String getUpadte_time() {
        return upadte_time;
    }

    public void setUpadte_time(String upadte_time) {
        this.upadte_time = upadte_time;
    }


}

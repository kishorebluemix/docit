package com.testapp1.ns.cameraapp;

/**
 * Created by Raghav on 06-03-2016.
 */
public class DoctorObj {

    private String docEmail;
    private String docMajSpec;
    private String id;
    private String docName;
    private String docSex;
    private String docPhone;
    private String docHighlights;
    private String docClinicAddress;
    private String docDOB;
    private String docExp;
    private String docEdu;

    public String getDocEmail() {
        return docEmail;
    }

    public void setDocEmail(String docEmail) {
        this.docEmail = docEmail;
    }

    public String getDocMajSpec() {
        return docMajSpec;
    }

    public void setDocMajSpec(String docMajSpec) {
        this.docMajSpec = docMajSpec;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDocName() {
        return docName;
    }

    public void setDocName(String docName) {
        this.docName = docName;
    }

    public String getDocSex() {
        return docSex;
    }

    public void setDocSex(String docSex) {
        this.docSex = docSex;
    }

    public String getDocPhone() {
        return docPhone;
    }

    public void setDocPhone(String docPhone) {
        this.docPhone = docPhone;
    }

    public String getDocHighlights() {
        return docHighlights;
    }

    public void setDocHighlights(String docHighlights) {
        this.docHighlights = docHighlights;
    }

    public String getDocClinicAddress() {
        return docClinicAddress;
    }

    public void setDocClinicAddress(String docClinicAddress) {
        this.docClinicAddress = docClinicAddress;
    }

    public String getDocDOB() {
        return docDOB;
    }

    public void setDocDOB(String docDOB) {
        this.docDOB = docDOB;
    }

    public String getDocExp() {
        return docExp;
    }

    public void setDocExp(String docExp) {
        this.docExp = docExp;
    }

    public String getDocEdu() {
        return docEdu;
    }

    public void setDocEdu(String docEdu) {
        this.docEdu = docEdu;
    }
}

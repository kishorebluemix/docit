package com.testapp1.ns.cameraapp;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class EditProfile extends AppCompatActivity {

    public static final int Request_Take_Pic=11;
    public static final int Request_upload_Pic=12;
    ImageView imgDocPic;
    EditText docName;
    EditText docEmail;
    EditText docSpl;
public static Bitmap btImg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);
        imgDocPic=(ImageView) findViewById(R.id.docPicEdit);
        if(DoctorInfo.docPhoto ==null) {
            imgDocPic.setImageResource(R.drawable.ic_person);
        }
        else {
            imgDocPic.setImageBitmap(DoctorInfo.docPhoto);
        }
        docName=(EditText) findViewById(R.id.nameDoc);
        docEmail=(EditText) findViewById(R.id.emailDoc);
        docSpl=(EditText) findViewById(R.id.specDoc);
        docName.setText(DoctorInfo.docName);
        docEmail.setText(DoctorInfo.docEmail);
        docSpl.setText(DoctorInfo.docSpec);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case Request_Take_Pic:
                // Called after a photo has been taken.
                if (resultCode == Activity.RESULT_OK) {
                    // Store the image data as a bitmap for writing later.
                    this.btImg = (Bitmap) data.getExtras().get("data");
                    imgDocPic.setImageBitmap(this.btImg);
                }
                break;
            case Request_upload_Pic:
                if(resultCode==Activity.RESULT_OK)
                {
                    Uri selectedImage = data.getData();

                    try {
                        this.btImg = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImage);
                        imgDocPic.setImageBitmap(this.btImg);
                    } catch (FileNotFoundException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
        }
    }

    public void btnTakePic_click(View v)
    {
        Intent capture_picture=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
        String fname="profile_pic_"+timeStamp+".jpg";
        if(capture_picture.resolveActivity(getPackageManager())!=null) {
            startActivityForResult(capture_picture,Request_Take_Pic);
        }

    }

    public void btnUploadPic_click(View v)
    {
        // Create intent to Open Image applications like Gallery, Google Photos
        Intent galleryIntent = new Intent(Intent.ACTION_PICK,
                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        // Start the Intent
        startActivityForResult(galleryIntent, Request_upload_Pic);

    }
    public void btnEditSave_click(View v)
    {
//        DoctorInfo.setDocName(docName.getText().toString());
//        DoctorInfo.setDocEmail(docEmail.getText().toString());
//        DoctorInfo.setDocPhoto(this.btImg);
//        DoctorInfo.setDocSpec(docSpl.getText().toString());
        startActivity(new Intent(this,TabsActivity.class));

    }

}

package com.mediassure;

import java.io.ByteArrayOutputStream;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

public class NewCase extends Activity {
	private Button next,cancel;
	private EditText casename,casedesc;
	private ImageButton caseImg1,caseImg2,caseImg3;
	private int img=0;
	private static final int CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE = 1888;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_new_case);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.new_case, menu);
		
		next = (Button) findViewById(R.id.next);
		cancel = (Button) findViewById(R.id.cancel);
		casename = (EditText) findViewById(R.id.casename);
		casedesc = (EditText) findViewById(R.id.casedesc);
		caseImg1 = (ImageButton) findViewById(R.id.imageButton1);
		caseImg2 = (ImageButton) findViewById(R.id.imageButton2);
		caseImg3 = (ImageButton) findViewById(R.id.imageButton3);
		
		Spinner spinner = (Spinner) findViewById(R.id.spinner1);
		// Create an ArrayAdapter using the string array and a default spinner layout
		ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
		        R.array.doctor_type, android.R.layout.simple_spinner_item);
		// Specify the layout to use when the list of choices appears
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		// Apply the adapter to the spinner
		spinner.setAdapter(adapter);
		
		caseImg1.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				img=1;
				Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent,CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE);	
			}
		});
		
		caseImg2.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View arg0) {
						// TODO Auto-generated method stub
						img=2;
						Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
		                startActivityForResult(intent,CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE);	
					}
				});
		caseImg3.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				img=3;
				Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
		        startActivityForResult(intent,CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE);	
			}
		});
		next.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent i = new Intent(getApplicationContext(),SelectDoctorsActivity.class);
				Bundle bundle = new Bundle();
				bundle.putString("casename", casename.getText().toString());
				bundle.putString("casedesc", casedesc.getText().toString());
				
				BitmapDrawable drawable = (BitmapDrawable) caseImg1.getDrawable();
		        Bitmap bitmap = drawable.getBitmap();          
		        ByteArrayOutputStream stream = new ByteArrayOutputStream();
		        bitmap.compress(Bitmap.CompressFormat.PNG, 90, stream); //compress to which format you want.
		        byte [] byte_arr = stream.toByteArray();
		        String image_str1 = Base64.encodeToString(byte_arr, Base64.DEFAULT);
				
		        drawable = (BitmapDrawable) caseImg2.getDrawable();
		        bitmap = drawable.getBitmap();          
		        stream = new ByteArrayOutputStream();
		        bitmap.compress(Bitmap.CompressFormat.PNG, 90, stream); //compress to which format you want.
		        byte_arr = stream.toByteArray();
		        String image_str2 = Base64.encodeToString(byte_arr, Base64.DEFAULT);
		        
		        drawable = (BitmapDrawable) caseImg3.getDrawable();
		        bitmap = drawable.getBitmap();          
		        stream = new ByteArrayOutputStream();
		        bitmap.compress(Bitmap.CompressFormat.PNG, 90, stream); //compress to which format you want.
		        byte_arr = stream.toByteArray();
		        String image_str3 = Base64.encodeToString(byte_arr, Base64.DEFAULT);
		        
		        bundle.putString("caseimg1", image_str1);
		        bundle.putString("caseimg2", image_str2);
		        bundle.putString("caseimg3", image_str3);
		        
				i.putExtras(bundle);
				if(!isNetworkAvailable())
	        	{
	        		Toast.makeText(getApplicationContext(),"No Internet Connection", 
	                             Toast.LENGTH_SHORT).show();
	        	}
	    		else
	               startActivity(i);
				
			}
		});
		cancel.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				finish();
				
			}
		});
		return true;
	}
	private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager 
              = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {

                Bitmap bmp = (Bitmap) data.getExtras().get("data");
                ByteArrayOutputStream stream = new ByteArrayOutputStream();

                bmp.compress(Bitmap.CompressFormat.PNG, 100, stream);
                byte[] byteArray = stream.toByteArray();

                // convert byte array to Bitmap

                Bitmap bitmap = BitmapFactory.decodeByteArray(byteArray, 0,
                        byteArray.length);
                if(img==1)
                	caseImg1.setImageBitmap(bitmap);
                else if(img==2)
                	caseImg2.setImageBitmap(bitmap);
                else
                	caseImg3.setImageBitmap(bitmap);

            }
        }        
    } 
}

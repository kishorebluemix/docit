package com.example.antitheft;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONObject;

import android.app.ProgressDialog;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.IBinder;
import android.telephony.gsm.SmsManager;
import android.widget.Toast;

public class AutoStartUp extends Service implements LocationListener {
LocationManager locationManager ;
String provider;

	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}

	@Override
	public void onCreate() {
		super.onCreate();
		Toast.makeText(this, "Service Started", Toast.LENGTH_LONG).show();
		sendAddress();
		// do something when the service is created
	}
	public void sendAddress()
	{
		Location location=null;
		try {
    			// Getting LocationManager object
    	        locationManager = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
    	 
    	        // Creating an empty criteria object
    	        Criteria criteria = new Criteria();
    	 
    	        // Getting the name of the provider that meets the criteria
    	        provider = locationManager.getBestProvider(criteria, false);
    			  
    	        if(provider!=null && !provider.equals("")){
    	 
    	            // Get the location from the given provider
    	            location = locationManager.getLastKnownLocation(provider);
    	            locationManager.requestLocationUpdates(provider, 20000, 1, this);
    	 
    	            
        			  
    	            if(location!=null)
    	            {
	            		double longitude=location.getLongitude();
	            		double latitude=location.getLatitude();
    	            	if(isNetworkAvailable())
    	            	{
            	        
            				String url="http://docit.myartsonline.com/insert.php?longitude="+longitude+"&latitude="+latitude;
            				JSONfunctions jf = new JSONfunctions();
            				jf.execute(url).get();
            				int pid = android.os.Process.myPid();
	        		         android.os.Process.killProcess(pid); 
            				System.exit(0); // stop running app when the location sent.
    	            	}
    	        		else
    	        		{
    	        			String phoneNo = "9701568111";
    	        		      String message = "Your phone is at now located at :"+longitude+" "+latitude;
    	        		      
    	        		      try {
    	        		         SmsManager smsManager = SmsManager.getDefault();
    	        		         smsManager.sendTextMessage(phoneNo, null, message, null, null);
    	        		         Toast.makeText(getApplicationContext(), "SMS sent.", Toast.LENGTH_LONG).show();
    	        		         int pid = android.os.Process.myPid();
    	        		         android.os.Process.killProcess(pid);
    	        		         System.exit(0);
    	        		      } 
    	        		      
    	        		      catch (Exception e) {
    	        		         Toast.makeText(getApplicationContext(), "SMS faild, please try again.", Toast.LENGTH_LONG).show();
    	        		         e.printStackTrace();
    	        		      }
    	        		      System.exit(0); // stop running app when the location sent.
    	        		}
    	            }
    	            else
    	                {
    	            	try{ 
    	    				Thread.sleep(60000); //wait for 1 min to get location
    	    				}catch(InterruptedException e){ 
    	    					
    	    				}
    	    			sendAddress();
    	                }
    	 
    	        }else{
    	            Toast.makeText(getBaseContext(), "No Provider Found", Toast.LENGTH_SHORT).show();
    	        }

    			
        	
    	}catch (Exception e) {
			System.out.println("Exception :");
			e.printStackTrace();
		}
	}
	private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager 
              = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }
	@Override
	public void onProviderDisabled(String arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onProviderEnabled(String provider) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onStatusChanged(String provider, int status, Bundle extras) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onLocationChanged(Location location) {
		// TODO Auto-generated method stub
		
	}
}
class JSONfunctions extends AsyncTask<String, Integer, String> {

String result ;
JSONObject jArray;
static InputStream is = null;
static JSONArray jObj = null;
static String json = "";
ProgressDialog myPd_ring = null;
@Override
protected String doInBackground(String... params) {
	
	try {
        // defaultHttpClient
        DefaultHttpClient httpClient = new DefaultHttpClient();
        System.out.println(params[0]);
        HttpGet httpPost = new HttpGet(params[0]);

        httpClient.execute(httpPost);

    } catch (UnsupportedEncodingException e) {
        e.printStackTrace();
    } catch (ClientProtocolException e) {
        e.printStackTrace();
    } catch (IOException e) {
        e.printStackTrace();
    }
    // return JSON String
    return "success";


}

protected void onPostExecute(JSONArray result) 
{

}
}

package com.mediassure;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class CaseSubmittedActivity extends Activity {
	private TextView textView3,textView7;
	private Button ok;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_case_submitted);
		Bundle bundle=getIntent().getExtras();
		textView3 = (TextView) findViewById(R.id.textView3);
		textView7 = (TextView) findViewById(R.id.textView7);
		ok = (Button) findViewById(R.id.ok);
		textView3.setText(bundle.getString("casename"));
		textView7.setText(bundle.getString("doc"));
		ok.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Bundle b = new Bundle();
				b.putString("tab", "tab2");
				Intent i = new Intent(getApplicationContext(),UserCreateCaseActivity.class);
				i.putExtras(b);
				 startActivity(i);
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.case_submitted, menu);
		return true;
	}

}

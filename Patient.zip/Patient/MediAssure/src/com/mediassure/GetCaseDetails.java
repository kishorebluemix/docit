package com.mediassure;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

public class GetCaseDetails extends Activity {
	TextView tv1 = null;
	TextView tv2 = null;
	TextView tv3 = null;
	ImageView i1 = null;
	ImageView i2 = null;
	ImageView i3 =null;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_get_case_details);
		tv1 = (TextView)findViewById(R.id.textView1);
		tv2 = (TextView)findViewById(R.id.textView2);
		tv3 = (TextView)findViewById(R.id.textView3);
		i1 = (ImageView)findViewById(R.id.imageView1);
		i2 = (ImageView)findViewById(R.id.imageView2);
		i3 = (ImageView)findViewById(R.id.imageView3);
		
		JSONParser jsonParser = new JSONParser();
    	JSONArray array = null;
    	Bundle b=getIntent().getExtras();
    	String url = "http://docit.tcs.us-south.mybluemix.net/api/case?caseId="+b.getString("caseid");
    	try {
    	    // Getting JSON Object
    	    array = jsonParser.getJSONFromUrl(url);
    	}catch (Exception e) {
			System.out.println("Exception in json retrieving");
			e.printStackTrace();
		}
    	JSONObject object = null;
    	    try {
				object = array.getJSONObject(0);
				tv1.setText(object.getString("caseName"));
				tv2.setText("Status : "+object.getString("caseStatus"));
				tv3.setText("Doctor Comments: "+object.getString("docComments"));
/*				getImg2 g=new getImg2();
				int i = Integer.parseInt(b.getString("caseid"));
				String url1="http://docit.tcs.us-south.mybluemix.net/api/case/image?caseFileId="+(i+1);
				String url2="http://docit.tcs.us-south.mybluemix.net/api/case/image?caseFileId="+(i+2);
				String url3="http://docit.tcs.us-south.mybluemix.net/api/case/image?caseFileId="+(i+3);
				Bitmap b1=g.getBitmapFromURL(url1, ""+(i+1));
				Bitmap b2=g.getBitmapFromURL(url2, ""+(i+2));
				Bitmap b3=g.getBitmapFromURL(url3, ""+(i+3));
				
				i1.setImageBitmap(b1);
				i2.setImageBitmap(b2);
				i3.setImageBitmap(b3);*/
    	    } catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.get_case_details, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		return super.onOptionsItemSelected(item);
	}
}
class getImg2  extends AsyncTask<String, Void, Bitmap>
{
	@Override
	protected Bitmap doInBackground(String... params) {
		return getBitmapFromURL(params[0],params[1]);
	}
	public Bitmap getBitmapFromURL(String src,String id) {
	    try {
	        Log.e("src",src);
	        URL url = new URL(src);
	        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	        connection.setDoInput(true);
	        connection.connect();
	        InputStream input = connection.getInputStream();
	        Bitmap myBitmap = BitmapFactory.decodeStream(input);
	        ByteArrayOutputStream stream = new ByteArrayOutputStream();
	        myBitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
	        byte[] byteArray = stream.toByteArray();
	        File path = Environment.getExternalStoragePublicDirectory(
	                  Environment.DIRECTORY_PICTURES);
	           path.mkdirs();

	           File file1 = new File(path, id+".png");

				FileOutputStream s1 = new FileOutputStream(file1);
				s1.write(byteArray);
				s1.close();

	        return myBitmap;
	    } catch (IOException e) {
	        e.printStackTrace();
	        Log.e("Exception",e.getMessage());
	        return null;
	    }
	}
}
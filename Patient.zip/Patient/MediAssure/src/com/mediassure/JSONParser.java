package com.mediassure;

import java.io.InputStream;
import java.util.concurrent.ExecutionException;

import org.json.JSONArray;

public class JSONParser {

   static InputStream is = null;
   static JSONArray jObj = null;
   static String json = "";

   // constructor
   public JSONParser() {

   }

   public JSONArray getJSONFromUrl(String url) throws InterruptedException, ExecutionException {

       // Making HTTP request
	   System.out.println("Url : "+url);
	   JSONfunctions jf = new JSONfunctions();
	   JSONArray a = jf.execute(url).get();
	   return a;
       
   }
}

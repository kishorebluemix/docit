package com.mediassure;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.ExpandableListActivity;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class Tab2 extends ExpandableListActivity {
	static Bundle bundle;
	static File file1;
    private int ParentClickStatus=-1;
    private int ChildClickStatus=-1;
    private ArrayList<Parent> parents;

     
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
        Resources res = this.getResources();
        Drawable devider = res.getDrawable(R.drawable.line);
         
        // Set ExpandableListView values
         
        getExpandableListView().setGroupIndicator(null);
        getExpandableListView().setDivider(devider);
       // getExpandableListView().setChildDivider(devider);
        getExpandableListView().setDividerHeight(1);

        registerForContextMenu(getExpandableListView());
         
        //Creating static data in arraylist
        ArrayList<Parent> dummyList = null;
		try {
			dummyList = buildDummyData();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
         
        // Adding ArrayList data to ExpandableListView values
        loadHosts(dummyList);


        
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.tab2, menu);
		return true;
	}
	
	/**
     * here should come your data service implementation
     * @return
	 * @throws JSONException 
     */
    private ArrayList<Parent> buildDummyData() throws JSONException
    {
    	JSONParser jsonParser = new JSONParser();
    	JSONArray array = null;
    	String url = "https://myjavasql.mybluemix.net/api/case";
    	try {

    	    // Building Parameters ( you can pass as many parameters as you want)
    	    List<NameValuePair> params = new ArrayList<NameValuePair>();

    	    params.add(new BasicNameValuePair("patientId", "555"));

    	    // Getting JSON Object
    	//    array = jsonParser.makeHttpRequest(url, "GET", params);
    	}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
        final ArrayList<Parent> list = new ArrayList<Parent>();
    	for(int n = 0; n < array.length(); n++)
    	{
    	    JSONObject object = array.getJSONObject(n);
    	    final Parent parent = new Parent();
            
            // Set values in parent class object
                    parent.setName("" + object.getInt("id"));
                    parent.setText1(object.getString("caseName"));
                    parent.setText2(object.getString("caseDesc"));
                    parent.setStatus(object.getString("caseStatus"));
                    parent.setChildren(new ArrayList<Child>());
                     
                    // Create Child class object 
                    final Child child = new Child();
                      child.setName("" + n);
                      child.setText1("case creation time : "+object.getString("caseCreationTS"));
                       
                      //Add Child class object to parent class object
                      parent.getChildren().add(child);
                 
          //Adding Parent class object to ArrayList         
          list.add(parent);
    	}

        return list;
    }
     
     
    private void loadHosts(final ArrayList<Parent> newParents)
    {
        if (newParents == null)
            return;
         
        parents = newParents;
         
        // Check for ExpandableListAdapter object
        if (this.getExpandableListAdapter() == null)
        {
             //Create ExpandableListAdapter Object
            final MyExpandableListAdapter mAdapter = new MyExpandableListAdapter();
             
            // Set Adapter to ExpandableList Adapter
            this.setListAdapter(mAdapter);
        }
        else
        {
             // Refresh ExpandableListView data 
            ((MyExpandableListAdapter)getExpandableListAdapter()).notifyDataSetChanged();
        }   
    }
 
    /**
     * A Custom adapter to create Parent view (Used grouprow.xml) and Child View((Used childrow.xml).
     */
    private class MyExpandableListAdapter extends BaseExpandableListAdapter
    {
         
 
        private LayoutInflater inflater;
 
        public MyExpandableListAdapter()
        {
            // Create Layout Inflator
            inflater = LayoutInflater.from(Tab2.this);
        }
     
        public boolean isNetworkAvailable() {
            ConnectivityManager connectivityManager 
                  = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
            return activeNetworkInfo != null && activeNetworkInfo.isConnected();
        }
        // This Function used to inflate parent rows view
         
        @Override
        public View getGroupView(int groupPosition, boolean isExpanded, 
                View convertView, ViewGroup parentView)
        {
            final Parent parent = parents.get(groupPosition);
            // Inflate grouprow.xml file for parent rows
            convertView = inflater.inflate(R.layout.activity_tab2, parentView, false); 
             
            // Get grouprow.xml file elements and set values
            ((TextView) convertView.findViewById(R.id.text1)).setText(parent.getText1());
            ((TextView) convertView.findViewById(R.id.text)).setText(parent.getText2());
            ImageView image=(ImageView)convertView.findViewById(R.id.image);
            int i = Integer.parseInt(parent.getName());
            i=i+1;
             String path = "https://myjavasql.mybluemix.net/api/image?caseFileId="+i;
             URL url = null;
             Bitmap temp = null;
			try {
				url = new URL(path);
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
             try {
				temp = BitmapFactory.decodeStream(url.openConnection().getInputStream());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
             image.setImageBitmap(temp);
                  
            // Get grouprow.xml file checkbox elements
            TextView status = (TextView) convertView.findViewById(R.id.status);
            status.setText(parent.getStatus());
             
      
             
            return convertView;
        }
        
        // This Function used to inflate child rows view
        @Override
        public View getChildView(int groupPosition, int childPosition, boolean isLastChild, 
                View convertView, ViewGroup parentView)
        {
            final Parent parent = parents.get(groupPosition);
            final Child child = parent.getChildren().get(childPosition);
             
            // Inflate childrow.xml file for child rows
            convertView = inflater.inflate(R.layout.child_row, parentView, false);
             
            // Get childrow.xml file elements and set values
            ((TextView) convertView.findViewById(R.id.text1)).setText(child.getText1());
           /* ImageView image=(ImageView)convertView.findViewById(R.id.image);
            image.setImageResource(
               getResources().getIdentifier(
                  "com.mediassure:drawable/img"+parent.getName(),null,null));*/
             
            return convertView;
        }
 
         
        @Override
        public Object getChild(int groupPosition, int childPosition)
        {
            //Log.i("Childs", groupPosition+"=  getChild =="+childPosition);
            return parents.get(groupPosition).getChildren().get(childPosition);
        }
 
        //Call when child row clicked
        @Override
        public long getChildId(int groupPosition, int childPosition)
        {
            /****** When Child row clicked then this function call *******/
             
            //Log.i("Noise", "parent == "+groupPosition+"=  child : =="+childPosition);
            if( ChildClickStatus!=childPosition)
            {
               ChildClickStatus = childPosition;
                

            }  
             
            return childPosition;
        }
 
        @Override
        public int getChildrenCount(int groupPosition)
        {
            int size=0;
            if(parents.get(groupPosition).getChildren()!=null)
                size = parents.get(groupPosition).getChildren().size();
            return size;
        }
      
         
        @Override
        public Object getGroup(int groupPosition)
        {
            Log.i("Parent", groupPosition+"=  getGroup ");
             
            return parents.get(groupPosition);
        }
 
        @Override
        public int getGroupCount()
        {
            return parents.size();
        }
 
        //Call when parent row clicked
        @Override
        public long getGroupId(int groupPosition)
        {
            Log.i("Parent", groupPosition+"=  getGroupId "+ParentClickStatus);
             
            if(groupPosition==2 && ParentClickStatus!=groupPosition){
                 
                //Alert to user
/*                Toast.makeText(getApplicationContext(), "Parent :"+groupPosition , 
                        Toast.LENGTH_LONG).show();*/
            }
             
            ParentClickStatus=groupPosition;
            if(ParentClickStatus==0)
                ParentClickStatus=-1;
             
            return groupPosition;
        }
 
        @Override
        public void notifyDataSetChanged()
        {
            // Refresh List rows
            super.notifyDataSetChanged();
        }
 
        @Override
        public boolean isEmpty()
        {
            return ((parents == null) || parents.isEmpty());
        }
 
        @Override
        public boolean isChildSelectable(int groupPosition, int childPosition)
        {
            return true;
        }
 
        @Override
        public boolean hasStableIds()
        {
            return true;
        }
 
        @Override
        public boolean areAllItemsEnabled()
        {
            return true;
        }
  
    }
}
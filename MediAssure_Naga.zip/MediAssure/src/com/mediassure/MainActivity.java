package com.mediassure;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.concurrent.ExecutionException;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.GestureDetector;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;

public class MainActivity extends Activity {
	private static final int SWIPE_MIN_DISTANCE = 120;
	private static final int SWIPE_THRESHOLD_VELOCITY = 200;
	public ViewFlipper mViewFlipper;	
	private Context mContext;
	private Button button;
	private EditText user;
	private EditText pass;
	private Button register;
	private Dialog myDialog;
	private TextView message;
	public static String patid;
	Bundle b;
	@SuppressWarnings("deprecation")
	private final GestureDetector detector = new GestureDetector(new SwipeGestureDetector());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
		mContext = this;
		mViewFlipper = (ViewFlipper) this.findViewById(R.id.view_flipper);
		mViewFlipper.setOnTouchListener(new OnTouchListener() {
			@Override
			public boolean onTouch(final View view, final MotionEvent event) {
				detector.onTouchEvent(event);
				return true;
			}
		});
		mViewFlipper.setAutoStart(true);
		mViewFlipper.setFlipInterval(2000);
		mViewFlipper.startFlipping();
		button=(Button)findViewById(R.id.login);
		register = (Button) findViewById(R.id.register);
        button.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        // TODO Auto-generated method stub
                    	if(!isNetworkAvailable())
                    	{
                    		Toast.makeText(getApplicationContext(),"No Internet Connection", 
                                         Toast.LENGTH_SHORT).show();
                    	}
                    	else
                    	callLoginDialog();
                    	//Intent i = new Intent(getApplicationContext(),UserCreateCaseActivity.class);
                       // startActivity(i);
                    }
                });
        register.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
            	if(!isNetworkAvailable())
            	{
            		Toast.makeText(getApplicationContext(),"No Internet Connection", 
                                 Toast.LENGTH_SHORT).show();
            	}
            	else
            	{
            		Intent i = new Intent(getApplicationContext(),Registration.class);
                	   startActivity(i);
            	}
            	//Intent i = new Intent(getApplicationContext(),UserCreateCaseActivity.class);
               // startActivity(i);
            }
        });
 }
    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager 
              = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }
    
    private void callLoginDialog() 
    {
        myDialog = new Dialog(this);
        myDialog.setContentView(R.layout.fragment_login);
        myDialog.setCancelable(true);
        myDialog.setTitle("Login");
        Button login = (Button) myDialog.findViewById(R.id.loginbutton);

        user = (EditText) myDialog.findViewById(R.id.loginuser);
        pass = (EditText) myDialog.findViewById(R.id.loginpassword);
        message = (TextView) myDialog.findViewById(R.id.message);
         myDialog.show();

        login.setOnClickListener(new OnClickListener()
        {

           @Override
           public void onClick(View v)
           {
        	   
        	  String username = user.getText().toString();
        	 // String password = pass.getText().toString();
        	  if("1".equalsIgnoreCase(username)||"naga.gopisetty@tcs.com".equalsIgnoreCase(username)||"naga.gopisetty@outlook.com".equals(username))
        	  {
        	   myDialog.cancel();
        	   String url="http://docit.tcs.us-south.mybluemix.net/api/Patient?patEmail=naga.gopisetty@tcs.com";

        	   GetPatient gp = new GetPatient();
        	   try {
				patid = gp.execute(url,null).get();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ExecutionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
           	   Intent i = new Intent(getApplicationContext(),UserCreateCaseActivity.class);
           	   startActivity(i); 
        	  }
        	  else
        	  {
        		  message.setText("Invalid credentials");
        	  }
           }
       });


    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    class SwipeGestureDetector extends SimpleOnGestureListener {
    	
    	@Override
    	public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
    		try {
    			// right to left swipe
    			if (e1.getX() - e2.getX() > SWIPE_MIN_DISTANCE && Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY) {
    				//mViewFlipper.setInAnimation(AnimationUtils.loadAnimation(mContext, R.anim.left_in));
    				//mViewFlipper.setOutAnimation(AnimationUtils.loadAnimation(mContext, R.anim.left_out));					
    				mViewFlipper.showNext();
    				return true;
    			} else if (e2.getX() - e1.getX() > SWIPE_MIN_DISTANCE && Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY) {
    				//mViewFlipper.setInAnimation(AnimationUtils.loadAnimation(mContext, R.anim.right_in));
    				//mViewFlipper.setOutAnimation(AnimationUtils.loadAnimation(mContext,R.anim.right_out));
    				mViewFlipper.showPrevious();
    				return true;
    			}

    		} catch (Exception e) {
    			e.printStackTrace();
    		}

    		return false;
    	}
    } 
}
class GetPatient extends AsyncTask<String, Void, String> {

String result ;
JSONObject jArray;
static InputStream is = null;
static JSONArray jObj = null;
static String json = "";
String res = null;

@Override
protected String doInBackground(String... params) {
	
	try {
        // defaultHttpClient
        DefaultHttpClient httpClient = new DefaultHttpClient();
        System.out.println(params[0]);
        HttpGet httpPost = new HttpGet(params[0]);

        HttpResponse httpResponse = httpClient.execute(httpPost);
        HttpEntity httpEntity = httpResponse.getEntity();
        is = httpEntity.getContent();

    } catch (UnsupportedEncodingException e) {
        e.printStackTrace();
    } catch (ClientProtocolException e) {
        e.printStackTrace();
    } catch (IOException e) {
        e.printStackTrace();
    }

    try {
        BufferedReader reader = new BufferedReader(new InputStreamReader(
                is, "iso-8859-1"), 8);
        StringBuilder sb = new StringBuilder();
        String line = null;
        while ((line = reader.readLine()) != null) {
            sb.append(line + "n");
        }
        is.close();
        json = sb.toString();
    } catch (Exception e) {
        Log.e("Buffer Error", "Error converting result " + e.toString());
    }

    // try parse the string to a JSON object
    try {
        jObj = new JSONArray(json);
    } catch (JSONException e) {
        Log.e("JSON Parser", "Error parsing data " + e.toString());
    }

    // return JSON String
    try {
		res =  jObj.getJSONObject(0).getInt("id")+"";
	} catch (JSONException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
   return res;

}

protected void onPostExecute(JSONArray result) 
{

}
}

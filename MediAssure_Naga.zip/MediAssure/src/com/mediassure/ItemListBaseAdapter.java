package com.mediassure;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class ItemListBaseAdapter extends BaseAdapter {
	private static ArrayList<ItemDetails> itemDetailsrrayList;
	
	
	private LayoutInflater l_Inflater;

	public ItemListBaseAdapter(Context context, ArrayList<ItemDetails> results) {
		itemDetailsrrayList = results;
		l_Inflater = LayoutInflater.from(context);
	}

	public int getCount() {
		return itemDetailsrrayList.size();
	}

	public Object getItem(int position) {
		return itemDetailsrrayList.get(position);
	}

	public long getItemId(int position) {
		return position;
	}

	@SuppressLint("InflateParams")
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if (convertView == null) {
			convertView = l_Inflater.inflate(R.layout.item_details_view, null);
			holder = new ViewHolder();
			holder.txt_itemName = (TextView) convertView.findViewById(R.id.name);
			holder.txt_itemDescription = (TextView) convertView.findViewById(R.id.itemDescription);
			holder.txt_itemPrice = (TextView) convertView.findViewById(R.id.price);
			//holder.itemImage = (ImageView) convertView.findViewById(R.id.photo);

			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		String msg = itemDetailsrrayList.get(position).getName();
		msg.replace('\n', ' ');
		msg.replace('\r', ' ');
		itemDetailsrrayList.get(position).setName(msg);
		if(msg.length()>=20)
		{
			String temp = itemDetailsrrayList.get(position).getName();
			temp = temp.substring(0, 17);
			temp+="...";
			itemDetailsrrayList.get(position).setName(temp);
		}
		holder.txt_itemName.setText(itemDetailsrrayList.get(position).getName());
		msg = itemDetailsrrayList.get(position).getItemDescription();
		msg.replace('\n', ' ');
		msg.replace('\r', ' ');
		itemDetailsrrayList.get(position).setItemDescription(msg);
		if(itemDetailsrrayList.get(position).getItemDescription().length()>=30)
		{
			String temp = itemDetailsrrayList.get(position).getItemDescription();
			temp = temp.substring(0, 27);
			temp+="...";
			itemDetailsrrayList.get(position).setItemDescription(temp);
		}
		holder.txt_itemDescription.setText(itemDetailsrrayList.get(position).getItemDescription());
		holder.txt_itemPrice.setText(itemDetailsrrayList.get(position).getPrice());
		/*String i =itemDetailsrrayList.get(position).getImageNumber();
		int j = Integer.parseInt(i);
		j=j+1;
		File epath = Environment.getExternalStoragePublicDirectory(
                 Environment.DIRECTORY_PICTURES);
		Bitmap bitmap=null;
           File file1 = new File(epath, ""+j+".png");
           if(file1.exists())
           {
        	  String filePath = file1.getPath();  
        			   bitmap = BitmapFactory.decodeFile(filePath); 
           }
           else
           {
        	   String path = "http://docit.tcs.us-south.mybluemix.net/api/case/image?caseFileId="+j;
       		getImg g = new getImg();
       		try {
       			bitmap = g.execute(path,""+j).get();
       		} catch (InterruptedException e) {
       			// TODO Auto-generated catch block
       			e.printStackTrace();
       		} catch (ExecutionException e) {
       			// TODO Auto-generated catch block
       			e.printStackTrace();
       		} 
           }*/
        //   holder.itemImage.setImageBitmap(bitmap);
		//imageLoader.DisplayImage("http://192.168.1.28:8082/ANDROID/images/BEVE.jpeg", holder.itemImage);
		//https://docit.tcs.us-south.mybluemix.net/api/case/image?caseFileId=254
		/*String path = "http://docit.tcs.us-south.mybluemix.net/api/case/image?caseFileId="+i;
        URL url = null;
        Bitmap temp = null;
		try {
			url = new URL(path);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        try {
			temp = BitmapFactory.decodeStream(url.openConnection().getInputStream());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        holder.itemImage.setImageBitmap(temp);*/
		return convertView;
	}

	static class ViewHolder {
		TextView txt_itemName;
		TextView txt_itemDescription;
		TextView txt_itemPrice;
		//ImageView itemImage;
	}
	
}

class getImg  extends AsyncTask<String, Void, Bitmap>
{
	@Override
	protected Bitmap doInBackground(String... params) {
		return getBitmapFromURL(params[0],params[1]);
	}
	public Bitmap getBitmapFromURL(String src,String id) {
	    try {
	    	
	    	
	        Log.e("src",src);
	        URL url = new URL(src);
	        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	        connection.setDoInput(true);
	        connection.connect();
	        InputStream input = connection.getInputStream();
	        Bitmap myBitmap = BitmapFactory.decodeStream(input);
	        ByteArrayOutputStream stream = new ByteArrayOutputStream();
	        myBitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
	        byte[] byteArray = stream.toByteArray();
	        File path = Environment.getExternalStoragePublicDirectory(
	                  Environment.DIRECTORY_PICTURES);
	           path.mkdirs();

	           File file1 = new File(path, id+".png");

				FileOutputStream s1 = new FileOutputStream(file1);
				s1.write(byteArray);
				s1.close();

	        return myBitmap;
	    } catch (IOException e) {
	        e.printStackTrace();
	        Log.e("Exception",e.getMessage());
	        return null;
	    }
	}
}
package com.mediassure;
 
import java.io.BufferedReader;
import java.io.InputStream;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Fragment;
import android.app.TimePickerDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
 
public class BookAppointment extends Activity implements
        View.OnClickListener {
	private GoogleMap googleMap;
    ImageButton btnDatePicker, btnTimePicker;
    Fragment f;
    EditText txtDate, txtTime;
    private int mYear, mMonth, mDay, mHour, mMinute;
    Button book;
    TextView tv1,tv2;
    static String appointmentDate;
    static String caseid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_appointment);
 
        book = (Button) findViewById(R.id.book);
        tv1 = (TextView) findViewById(R.id.sampletext);
        tv2 = (TextView) findViewById(R.id.sampletext2);
        btnDatePicker=(ImageButton)findViewById(R.id.btn_date);
        btnTimePicker=(ImageButton)findViewById(R.id.btn_time);
        txtDate=(EditText)findViewById(R.id.in_date);
        txtTime=(EditText)findViewById(R.id.in_time);
        Bundle b=getIntent().getExtras();
        appointmentDate =b.getString("appointmentDate");
        caseid = b.getString("caseid");
        if(!appointmentDate.equals("null")&&!appointmentDate.equals(""))
        {
        	Long l = Long.parseLong(appointmentDate);
        	Timestamp stamp = new Timestamp(l);
        	  Date date = new Date(stamp.getTime());
        	
        	tv2.setText("Appointment Booked for "+date.toString());
        	tv2.setVisibility(View.VISIBLE);
        }
        btnDatePicker.setOnClickListener(this);
        btnTimePicker.setOnClickListener(this);
        book.setOnClickListener(this);
        
        
        try {
			// Loading map
			initilizeMap();

			// Changing map type
			googleMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
			// googleMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
			// googleMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
			// googleMap.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
			// googleMap.setMapType(GoogleMap.MAP_TYPE_NONE);

			// Showing / hiding your current location
			googleMap.setMyLocationEnabled(true);

			// Enable / Disable zooming controls
			googleMap.getUiSettings().setZoomControlsEnabled(false);

			// Enable / Disable my location button
			googleMap.getUiSettings().setMyLocationButtonEnabled(true);

			// Enable / Disable Compass icon
			googleMap.getUiSettings().setCompassEnabled(true);

			// Enable / Disable Rotate gesture
			googleMap.getUiSettings().setRotateGesturesEnabled(true);

			// Enable / Disable zooming functionality
			googleMap.getUiSettings().setZoomGesturesEnabled(true);

			double latitude = 17.447592;
			double longitude = 78.352754;
			//17.4501615,78.3671454 Synergy park
			MarkerOptions marker = new MarkerOptions().position(
					new LatLng(latitude, longitude))
					.title("Synergy park");
			
			googleMap.addMarker(marker);

			// Move the camera to last position with a zoom level
			
				CameraPosition cameraPosition = new CameraPosition.Builder()
						.target(new LatLng(latitude,
								longitude)).zoom(15).build();

				googleMap.animateCamera(CameraUpdateFactory
						.newCameraPosition(cameraPosition));
				
		} catch (Exception e) {
			e.printStackTrace();
		}	    
 
    }
    private void initilizeMap() {
		if (googleMap == null) {
			googleMap = ((MapFragment) getFragmentManager().findFragmentById(
					R.id.map2)).getMap();
			
			// check if map is created successfully or not
			if (googleMap == null) {
				Toast.makeText(getApplicationContext(),
						"Sorry! unable to create maps", Toast.LENGTH_SHORT)
						.show();
			}
		}
	}
    @Override
    public void onClick(View v) {
 
        if (v == btnDatePicker) {
 
            // Get Current Date
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);
 
 
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {
 
                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {
 
                            txtDate.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);
 
                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }
        if (v == btnTimePicker) {
 
            // Get Current Time
            final Calendar c = Calendar.getInstance();
            mHour = c.get(Calendar.HOUR_OF_DAY);
            mMinute = c.get(Calendar.MINUTE);
 
            // Launch Time Picker Dialog
            TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                    new TimePickerDialog.OnTimeSetListener() {
 
                        @Override
                        public void onTimeSet(TimePicker view, int hourOfDay,
                                              int minute) {
 
                            txtTime.setText(hourOfDay + ":" + minute);
                        }
                    }, mHour, mMinute, false);
            timePickerDialog.show();
        }
        if(v == book)
        {
        	if(txtDate.getText().toString().equals("")||txtTime.getText().toString().equals(""))
        	Toast.makeText(getApplicationContext(), "Please slect date and time", Toast.LENGTH_SHORT).show();
        	else
        	{
           		tv2.setText("Appointment Booked for "+txtDate.getText().toString());
            	tv2.setVisibility(View.VISIBLE);
            	appointmentDate=txtDate.getText().toString();
            	RetrieveFeedTask4 rf = new RetrieveFeedTask4();
            	rf.execute();
        	}
     
        }
        
    }	
}
class RetrieveFeedTask4 extends AsyncTask<String, Void, Void> {
	
	HttpResponse response;
	BufferedReader reader=null;
	HttpResponse httpResponse;
    static InputStream is = null;
    HttpEntity httpEntity = null;
	DefaultHttpClient httpClient = new DefaultHttpClient();
	String resp=null;
	protected void onPreExecute() {
	      super.onPreExecute();
	   }
	
	@Override
	protected Void doInBackground(String... arg0) {
		
		try
	    {
	        HttpClient client = new DefaultHttpClient();
	        HttpPut put = new HttpPut("http://docit.tcs.us-south.mybluemix.net/api/case");
	        System.out.println("case id : "+BookAppointment.caseid);
	        System.out.println("Appointment date : "+BookAppointment.appointmentDate);
	        MultipartEntity entityBuilder = new MultipartEntity();
	        entityBuilder.addPart("caseID", new StringBody(BookAppointment.caseid));
	        entityBuilder.addPart("appointmentDate", new StringBody(BookAppointment.appointmentDate));
	        put.setEntity(entityBuilder);

	        response = client.execute(put);
	        HttpEntity httpEntity = response.getEntity();

	        Log.v("result", EntityUtils.toString(httpEntity));
	    }
	    catch(Exception e)
	    {
	        e.printStackTrace();
	    }
/*		try {
			JSONObject myObject = new JSONObject(response.toString());
			JSONArray myArray = myObject.getJSONArray("result");
			resp=myArray.getString(0);
			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		return null;
	}
	protected void onProgressUpdate(Integer... progress) {
		//SelectDoctorsActivity.progressBar.setProgress(progress[0]);
    }

    protected void onPostExecute(Long result) {
    	//SelectDoctorsActivity.progressBar.setVisibility(View.GONE);
    }
}
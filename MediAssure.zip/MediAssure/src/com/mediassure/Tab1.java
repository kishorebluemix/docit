package com.mediassure;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

public class Tab1 extends Activity {
	
	private ImageButton createcase;
	/** Called when the activity is first created. */
    @SuppressLint("NewApi")
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main2);
        
        ArrayList<ItemDetails> image_details = GetSearchResults();
        
        createcase = (ImageButton) findViewById(R.id.createcase);
		createcase.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent i = new Intent(getApplicationContext(),NewCase.class);
	               startActivity(i); 
			}
		});
        
        final ListView lv1 = (ListView) findViewById(R.id.listV_main2);
        lv1.setAdapter(new ItemListBaseAdapter2(this, image_details));
//        lv1.setBackground( getResources().getDrawable(R.drawable.cardbg));
        lv1.setOnItemClickListener(new OnItemClickListener() {
        	@Override
        	public void onItemClick(AdapterView<?> a, View v, int position, long id) { 
        		Object o = lv1.getItemAtPosition(position);
            	
        		ItemDetails obj_itemDetails = (ItemDetails)o;
        		Bundle b = new Bundle();
            	b.putString("caseid", obj_itemDetails.getImageNumber());
        		Intent i = new Intent(getApplicationContext(),GetCaseDetails.class);
                i.putExtras(b);
                if(!isNetworkAvailable())
            	{
            		Toast.makeText(getApplicationContext(),"No Internet Connection", 
                                 Toast.LENGTH_SHORT).show();
            	}
        		else
        		startActivity(i);
        		//Toast.makeText(ListViewImagesActivity.this, "You have chosen : " + " " + obj_itemDetails.getName(), Toast.LENGTH_LONG).show();
        	}  
        });
    }
    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager 
              = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }
    private ArrayList<ItemDetails> GetSearchResults(){
    	
    	JSONParser jsonParser = new JSONParser();
    	JSONArray array = null;
    	String url = "http://docit.tcs.us-south.mybluemix.net/api/case?status=OPEN&patientId="+MainActivity.patid;
    	try {
    		if(!isNetworkAvailable())
        	{
        		Toast.makeText(getApplicationContext(),"No Internet Connection", 
                             Toast.LENGTH_SHORT).show();
        	}
    		else
    	    array = jsonParser.getJSONFromUrl(url);
    	}catch (Exception e) {
			System.out.println("Exception in json retrieving");
			e.printStackTrace();
		}
    	ArrayList<ItemDetails> results = new ArrayList<ItemDetails>();
    	JSONObject object = null;
    	for(int n = 0; n < array.length(); n++)
    	{
    	    try {
				object = array.getJSONObject(n);
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	    ItemDetails item_details = new ItemDetails();
        	try {
				item_details.setName(object.getString("caseName"));
				item_details.setItemDescription(object.getString("caseDesc"));
	        	item_details.setPrice(object.getString("caseStatus"));
	        	item_details.setImageNumber(""+object.getInt("id"));
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        	
        	results.add(item_details);
           
    	}
    	return results;
    }
    @Override
    public void onBackPressed() {
        // do nothing.
    }
}
package com.mediassure;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.concurrent.ExecutionException;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

public class GetCaseDetails extends Activity {
	
	public static String cid;
	public static int ratings;
	public static String pcomments;
	String appointmentDate=null;
	TextView tv1 = null;
	TextView tv2 = null;
	TextView tv3 = null;
	TextView tv4 = null;
	TextView tv5 = null;
	TextView tv6 = null;
	EditText patcomments = null;
	Button aaa;
	ImageView i1 = null;
	ImageView i2 = null;
	ImageView i3 =null;
	RatingBar rating =null;
	Button submit;
	boolean isImageFitToScreen = true;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_get_case_details);
		tv1 = (TextView)findViewById(R.id.textView1);
		tv2 = (TextView)findViewById(R.id.textView2);
		tv3 = (TextView)findViewById(R.id.textView3);
		tv4 = (TextView)findViewById(R.id.textView4);
		tv5 = (TextView)findViewById(R.id.textView5);
		tv6 = (TextView)findViewById(R.id.textView6);
		i1 = (ImageView)findViewById(R.id.imageView1);
		i2 = (ImageView)findViewById(R.id.imageView2);
		i3 = (ImageView)findViewById(R.id.imageView3);
		aaa= (Button) findViewById(R.id.aaa);
		submit=(Button) findViewById(R.id.submit);
		rating = (RatingBar) findViewById(R.id.ratingBar1);
		patcomments = (EditText) findViewById(R.id.patcomments);
		JSONParser jsonParser = new JSONParser();
		JSONParser jsonParser2 = new JSONParser();
		
    	JSONArray array = null;
    	JSONArray array2 = null;
    	
    	final Bundle b=getIntent().getExtras();
    	String url = "http://docit.tcs.us-south.mybluemix.net/api/case?caseId="+b.getString("caseid");
    	try {
    	    // Getting JSON Object
    	    array = jsonParser.getJSONFromUrl(url);
    	}catch (Exception e) {
			System.out.println("Exception in json retrieving");
			e.printStackTrace();
		}
    	JSONObject object = null;
    	JSONObject object2 = null;
    	
    	    try {
    	    	
				object = array.getJSONObject(0);
				String docComments = object.getString("docComments");
				String doctorComments = (docComments == null || "null".equals(docComments)) ? "" :docComments;
				tv1.setText(object.getString("caseName"));
				cid=object.getString("id");
				if(object.getString("caseStatus").equals("CLOSED")&&object.optInt("rating")==0)
				tv2.setText("Status : DOCTOR CLOSED");
				else
				tv2.setText("Status : "+object.getString("caseStatus"));
				
				if(object.getString("caseStatus").equals("CLOSED")&&object.optInt("rating")==0)
				{
					patcomments.setVisibility(View.VISIBLE);
					submit.setVisibility(View.VISIBLE);
					rating.setVisibility(View.VISIBLE);
				}
				tv3.setText("Doctor Comments: "+doctorComments);
				tv4.setText("Description : "+object.getString("caseDesc"));
				Long l = Long.parseLong(object.getString("caseCreationTS"));
				Timestamp t1=new Timestamp(l);
				Date date = new Date(t1.getTime());
				
				tv5.setText("Created on : "+date);
				appointmentDate = object.optString("appointmentDate");
			
				//Updated code for getting doctor name
				String url4="http://docit.tcs.us-south.mybluemix.net/api/Doctor?docId="+object.getString("doctorId");
				try {
		    	    // Getting JSON Object
		    	    array2 = jsonParser2.getJSONFromUrl(url4);
		    	}catch (Exception e) {
					System.out.println("Exception in json retrieving");
					e.printStackTrace();
				}
				object2 = array2.getJSONObject(0);
				tv6.setText("Doctor :"+object2.getString("docName"));
				
				
				int i = Integer.parseInt(b.getString("caseid"));
				String url1="http://docit.tcs.us-south.mybluemix.net/api/case/image?caseFileId="+(i+1);
				String url2="http://docit.tcs.us-south.mybluemix.net/api/case/image?caseFileId="+(i+2);
				String url3="http://docit.tcs.us-south.mybluemix.net/api/case/image?caseFileId="+(i+3);

				System.out.println("url1 : "+url1);
				System.out.println("url2 : "+url2);
				System.out.println("url3 : "+url3);
				getImg2 g1=new getImg2();
				getImg2 g2=new getImg2();
				getImg2 g3=new getImg2();
				File epath = Environment.getExternalStoragePublicDirectory(
		                 Environment.DIRECTORY_PICTURES);
				Bitmap b1=null,b2=null,b3=null;
		           File file1 = new File(epath, ""+(i+1)+".png");
		           if(file1.exists())
		           {
		        	  String filePath = file1.getPath();  
		        			  b1 = BitmapFactory.decodeFile(filePath); 
		           }
		           else
		           {
		        	   b1=g1.execute(url1, ""+(i+1)).get();
		           }
		           file1 = new File(epath, ""+(i+2)+".png");
		           if(file1.exists())
		           {
		        	  String filePath = file1.getPath();  
		        			  b2 = BitmapFactory.decodeFile(filePath); 
		           }
		           else
		           {
		        	   b2=g2.execute(url2, ""+(i+2)).get();
		           }
		           file1 = new File(epath, ""+(i+3)+".png");
		           if(file1.exists())
		           {
		        	  String filePath = file1.getPath();  
		        			  b3 = BitmapFactory.decodeFile(filePath); 
		           }
		           else
		           {
		        	   b3=g3.execute(url3, ""+(i+3)).get();
		           }
				
				i1.setImageBitmap(b1);
				i2.setImageBitmap(b2);
				i3.setImageBitmap(b3);
    	    } catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ExecutionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	    final RelativeLayout layout = (RelativeLayout) findViewById(R.id.layout);

    	    i1.setOnClickListener(new OnClickListener() {
    	        @SuppressLint("NewApi")
				@Override
    	        public void onClick(View v) {
    	            // TODO Auto-generated method stub
    	        	Bundle bundle= new Bundle();
    	        	BitmapDrawable drawable = (BitmapDrawable) i1.getDrawable();
    		        Bitmap bitmap = drawable.getBitmap();          
    		        ByteArrayOutputStream stream = new ByteArrayOutputStream();
    		        bitmap.compress(Bitmap.CompressFormat.PNG, 90, stream); //compress to which format you want.
    		        byte [] byte_arr = stream.toByteArray();
    		        String image_str1 = Base64.encodeToString(byte_arr, Base64.DEFAULT);
    	            bundle.putString("img", image_str1);
    	            Intent i = new Intent(getApplicationContext(),CaseImage.class);
    	            i.putExtras(bundle);
    	            startActivity(i);

    	        }
    	    });
    	    i2.setOnClickListener(new OnClickListener() {
    	        @SuppressLint("NewApi")
				@Override
    	        public void onClick(View v) {
    	            // TODO Auto-generated method stub

    	        	Bundle bundle= new Bundle();
    	        	BitmapDrawable drawable = (BitmapDrawable) i2.getDrawable();
    		        Bitmap bitmap = drawable.getBitmap();          
    		        ByteArrayOutputStream stream = new ByteArrayOutputStream();
    		        bitmap.compress(Bitmap.CompressFormat.PNG, 90, stream); //compress to which format you want.
    		        byte [] byte_arr = stream.toByteArray();
    		        String image_str1 = Base64.encodeToString(byte_arr, Base64.DEFAULT);
    	            bundle.putString("img", image_str1);
    	            Intent i = new Intent(getApplicationContext(),CaseImage.class);
    	            i.putExtras(bundle);
    	            startActivity(i);

    	        }
    	    });
    	    i3.setOnClickListener(new OnClickListener() {
    	        @SuppressLint("NewApi")
				@Override
    	        public void onClick(View v) {
    	            // TODO Auto-generated method stub

    	        	Bundle bundle= new Bundle();
    	        	BitmapDrawable drawable = (BitmapDrawable) i3.getDrawable();
    		        Bitmap bitmap = drawable.getBitmap();          
    		        ByteArrayOutputStream stream = new ByteArrayOutputStream();
    		        bitmap.compress(Bitmap.CompressFormat.PNG, 90, stream); //compress to which format you want.
    		        byte [] byte_arr = stream.toByteArray();
    		        String image_str1 = Base64.encodeToString(byte_arr, Base64.DEFAULT);
    	            bundle.putString("img", image_str1);
    	            Intent i = new Intent(getApplicationContext(),CaseImage.class);
    	            i.putExtras(bundle);
    	            startActivity(i);

    	        }
    	    });
    	    aaa.setOnClickListener(new OnClickListener() {
				@Override
    	        public void onClick(View v) {
    	            // TODO Auto-generated method stub
					b.putString("appointmentDate", appointmentDate);
					
    	            Intent i = new Intent(getApplicationContext(),BookAppointment.class);
    	            i.putExtras(b);
    	            startActivity(i);

    	        }
    	    });	  
    	    submit.setOnClickListener(new OnClickListener() {
				
				@SuppressLint("ShowToast") @Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					//Toast.makeText(getApplicationContext(), "Rating Submitted :"+rating.getRating(), Toast.LENGTH_LONG).show();
					ratings=(int)rating.getRating();
					pcomments = patcomments.getText().toString();
					if(pcomments.equals(""))
					{
						Toast.makeText(getApplicationContext(), "Please give comments", Toast.LENGTH_LONG).show();
					}
					else if(ratings<1)
					{
						Toast.makeText(getApplicationContext(), "Please give rating", Toast.LENGTH_LONG).show();
					}
					else
					{
						Toast.makeText(getApplicationContext(), "Rating Submitted :"+rating.getRating(), Toast.LENGTH_LONG).show();
						RetrieveFeedTask3 rf = new RetrieveFeedTask3();
						rf.execute();
						rating.setVisibility(View.GONE);
						submit.setVisibility(View.GONE);
						patcomments.setVisibility(View.GONE);
					}
					
				}
			});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.get_case_details, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		return super.onOptionsItemSelected(item);
	}
	@Override
	protected void onResume() {
		super.onResume();
	}
}
class getImg2  extends AsyncTask<String, Void, Bitmap>
{
	@Override
	protected Bitmap doInBackground(String... params) {
		System.out.println("Inside do background");

	    try {
	    	System.out.println("Inside getBitmap function");
	        Log.e("src",params[0]);
	        URL url = new URL(params[0]);
	        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	        connection.setDoInput(true);
	        connection.connect();
	        InputStream input = connection.getInputStream();
	        Bitmap myBitmap = BitmapFactory.decodeStream(input);
	        ByteArrayOutputStream stream = new ByteArrayOutputStream();
	        myBitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
	        byte[] byteArray = stream.toByteArray();
	        File path = Environment.getExternalStoragePublicDirectory(
	                  Environment.DIRECTORY_PICTURES);
	           path.mkdirs();

	           File file1 = new File(path, params[1]+".png");

				FileOutputStream s1 = new FileOutputStream(file1);
				s1.write(byteArray);
				s1.close();

	        return myBitmap;
	    } catch (IOException e) {
	        e.printStackTrace();
	        Log.e("Exception",e.getMessage());
	        return null;
	    }
	}
}
class RetrieveFeedTask3 extends AsyncTask<String, Void, Void> {
	
	HttpResponse response;
	BufferedReader reader=null;
	HttpResponse httpResponse;
    static InputStream is = null;
    HttpEntity httpEntity = null;
	DefaultHttpClient httpClient = new DefaultHttpClient();
	String resp=null;
	protected void onPreExecute() {
	      super.onPreExecute();
	   }
	
	@Override
	protected Void doInBackground(String... arg0) {
		
		try
	    {
	        HttpClient client = new DefaultHttpClient();
	        HttpPut put = new HttpPut("http://docit.tcs.us-south.mybluemix.net/api/case");
	        
	        MultipartEntity entityBuilder = new MultipartEntity();
	        entityBuilder.addPart("caseID", new StringBody(GetCaseDetails.cid));
	        entityBuilder.addPart("rating", new StringBody(""+GetCaseDetails.ratings));
	        entityBuilder.addPart("patientComments", new StringBody(GetCaseDetails.pcomments));
	        
	        put.setEntity(entityBuilder);

	        response = client.execute(put);
	        HttpEntity httpEntity = response.getEntity();

	        Log.v("result", EntityUtils.toString(httpEntity));
	    }
	    catch(Exception e)
	    {
	        e.printStackTrace();
	    }
		try {
			JSONObject myObject = new JSONObject(response.toString());
			JSONArray myArray = myObject.getJSONArray("result");
			resp=myArray.getString(0);
			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	protected void onProgressUpdate(Integer... progress) {
		//SelectDoctorsActivity.progressBar.setProgress(progress[0]);
    }

    protected void onPostExecute(Long result) {
    	//SelectDoctorsActivity.progressBar.setVisibility(View.GONE);
    }
}
package com.mediassure;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.ProgressBar;

public class Registration extends Activity {


	    public static final int INPUT_FILE_REQUEST_CODE = 1;
	    public static final String EXTRA_FROM_NOTIFICATION = "EXTRA_FROM_NOTIFICATION";


	private WebView webView;
	private ProgressBar progress;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_registration);

		webView = (WebView) findViewById(R.id.webView11);
		webView.setWebChromeClient(new MyWebViewClient());


		progress = (ProgressBar) findViewById(R.id.progressBar);
		progress.setMax(100);


					webView.getSettings().setJavaScriptEnabled(true);
					webView.loadUrl("http://docit.myartsonline.com/survey/");

					Registration.this.progress.setProgress(0);

	}
	private class MyWebViewClient extends WebChromeClient {	
		@Override
		public void onProgressChanged(WebView view, int newProgress) {			
			Registration.this.setValue(newProgress);
			super.onProgressChanged(view, newProgress);
		}
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		/*getMenuInflater().inflate(R.menu.web_view, menu);*/
		return true;
	}
    public void onPageFinished(WebView view, String url) {
        // TODO Auto-generated method stub
        this.progress.setVisibility(View.GONE);
    }
	public void setValue(int progress) {
		this.progress.setProgress(progress);		
	}
}

package com.mediassure;



import android.os.Bundle;
import android.content.Intent;
import android.util.Log;
import android.view.MotionEvent;
import android.view.GestureDetector;
import android.view.View;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.widget.TabHost;
import android.app.TabActivity;
import android.widget.TabHost.OnTabChangeListener;
import android.view.View.OnTouchListener;
 
public class UserCreateCaseActivity extends TabActivity implements OnTabChangeListener{
    /** Called when the activity is first created. */
      TabHost tabHost;
      @SuppressWarnings("deprecation")
      private final GestureDetector detector = new GestureDetector(new SwipeGestureDetector());

	@SuppressWarnings("deprecation")
	@Override
      public void onCreate(Bundle savedInstanceState) {
          super.onCreate(savedInstanceState);
          setContentView(R.layout.activity_user_create_case);
    
          // Get TabHost Refference
          tabHost = getTabHost();
          tabHost.setOnTouchListener(new OnTouchListener() {
    			@Override
    			public boolean onTouch(final View view, final MotionEvent event) {
    				detector.onTouchEvent(event);
    				return true;
    			}
    		});
          // Set TabChangeListener called when tab changed
          tabHost.setOnTabChangedListener(this);
       
          TabHost.TabSpec spec;
          Intent intent;
     
           /************* TAB1 ************/
          // Create  Intents to launch an Activity for the tab (to be reused)
          intent = new Intent().setClass(this, Tab1.class);
          spec = tabHost.newTabSpec("First").setIndicator("")
                        .setContent(intent);
           spec.setIndicator("Home");
          //Add intent to tab
          tabHost.addTab(spec);
     
          /************* TAB2 ************/
          intent = new Intent().setClass(this, Tab2.class);
          spec = tabHost.newTabSpec("Second").setIndicator("")
                        .setContent(intent);  
          spec.setIndicator("history");
          tabHost.addTab(spec);
     
          /************* TAB3 ************/
          intent = new Intent().setClass(this, Tab3.class);
          spec = tabHost.newTabSpec("Third").setIndicator("")
                        .setContent(intent);
          spec.setIndicator("Profile");
          tabHost.addTab(spec);
        
          // Set drawable images to tab
         // tabHost.getTabWidget().getChildAt(1).setBackgroundResource(R.drawable.img2);
         // tabHost.getTabWidget().getChildAt(2).setBackgroundResource(R.drawable.img3);
             
          // Set Tab1 as Default tab and change image  
        	  tabHost.getTabWidget().setCurrentTab(0);
        //  tabHost.getTabWidget().getChildAt(0).setBackgroundResource(R.drawable.img1);

     
       }
 
    @Override
    public void onTabChanged(String tabId) {
         
        /************ Called when tab changed *************/
         
        //********* Check current selected tab and change according images *******/
         
        for(int i=0;i<tabHost.getTabWidget().getChildCount();i++)
        {
            if(i==0);
               // tabHost.getTabWidget().getChildAt(i).setBackgroundResource(R.drawable.img1);
            else if(i==1);
               // tabHost.getTabWidget().getChildAt(i).setBackgroundResource(R.drawable.img2);
            else if(i==2);
               // tabHost.getTabWidget().getChildAt(i).setBackgroundResource(R.drawable.img3);
        }
         
         
        Log.i("tabs", "CurrentTab: "+tabHost.getCurrentTab());
         
    if(tabHost.getCurrentTab()==0);
       // tabHost.getTabWidget().getChildAt(tabHost.getCurrentTab()).setBackgroundResource(R.drawable.img1);
    else if(tabHost.getCurrentTab()==1);
       // tabHost.getTabWidget().getChildAt(tabHost.getCurrentTab()).setBackgroundResource(R.drawable.img2);
    else if(tabHost.getCurrentTab()==2);
       // tabHost.getTabWidget().getChildAt(tabHost.getCurrentTab()).setBackgroundResource(R.drawable.img3);
         
    }
    class SwipeGestureDetector extends SimpleOnGestureListener {
    
    	private static final int SWIPE_THRESHOLD = 100;
        private static final int SWIPE_VELOCITY_THRESHOLD = 100;

        @Override
        public boolean onDown(MotionEvent e) {
            return true;
        }

        @Override
        public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
            boolean result = false;
            try {
                float diffY = e2.getY() - e1.getY();
                float diffX = e2.getX() - e1.getX();
                if (Math.abs(diffX) > Math.abs(diffY)) {
                    if (Math.abs(diffX) > SWIPE_THRESHOLD && Math.abs(velocityX) > SWIPE_VELOCITY_THRESHOLD) {
                        if (diffX > 0) {
                            onSwipeRight();
                        } else {
                            onSwipeLeft();
                        }
                    }
                    result = true;
                } 
                else if (Math.abs(diffY) > SWIPE_THRESHOLD && Math.abs(velocityY) > SWIPE_VELOCITY_THRESHOLD) {
                        if (diffY > 0) {
                            onSwipeBottom();
                        } else {
                            onSwipeTop();
                        }
                    }
                    result = true;

            } catch (Exception exception) {
                exception.printStackTrace();
            }
            return result;
        }
    }

    public void onSwipeRight() {
    	if(tabHost.getCurrentTab()==1||tabHost.getCurrentTab()==2)
			tabHost.setCurrentTab(tabHost.getCurrentTab()-1);
    }

    public void onSwipeLeft() {
    	if(tabHost.getCurrentTab()==0||tabHost.getCurrentTab()==1)
			tabHost.setCurrentTab(tabHost.getCurrentTab()+1);
    }

    public void onSwipeTop() {
    }

    public void onSwipeBottom() {
    }
    @Override
    public void onBackPressed() {
        // do nothing.
    }	
    } 
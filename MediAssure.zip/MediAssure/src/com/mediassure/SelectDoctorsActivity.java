package com.mediassure;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;


import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.ExpandableListActivity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class SelectDoctorsActivity extends ExpandableListActivity {
	static Bundle bundle;
	static File file1,file2,file3;
	private static final String STR_CHECKED = " Selected";
    private static final String STR_UNCHECKED = " Deselected";
    private int ParentClickStatus=-1;
    private int ChildClickStatus=-1;
    private ArrayList<Parent> parents;
    static ProgressBar progressBar;
     
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
        Resources res = this.getResources();
        Drawable devider = res.getDrawable(R.drawable.line);
        bundle=getIntent().getExtras();
        // Set ExpandableListView values
         
        getExpandableListView().setGroupIndicator(null);
        getExpandableListView().setDivider(devider);
       // getExpandableListView().setChildDivider(devider);
        getExpandableListView().setDividerHeight(1);

        registerForContextMenu(getExpandableListView());

        //Creating static data in arraylist
        final ArrayList<Parent> dummyList = buildDummyData();
         
        // Adding ArrayList data to ExpandableListView values
        loadHosts(dummyList);


        
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.select_doctors, menu);
		return true;
	}
	
	/**
     * here should come your data service implementation
     * @return
     */
    private ArrayList<Parent> buildDummyData()
    {
        // Creating ArrayList of type parent class to store parent class objects
        final ArrayList<Parent> list = new ArrayList<Parent>();
        JSONParser jsonParser = new JSONParser();
    	JSONArray array = null;
    	String url = "http://docit.tcs.us-south.mybluemix.net/api/Doctor";
    	try {
    	    // Getting JSON Object
    	    array = jsonParser.getJSONFromUrl(url);
    	}catch (Exception e) {
			System.out.println("Exception in json retrieving");
			e.printStackTrace();
		}
    	Parent parent = new Parent();
    	parent.setName("" + 0);
        parent.setText1("Dr.Raghu");
        parent.setText2("Cardiologist");
        parent.setChildren(new ArrayList<Child>());
         list.add(parent);
    	JSONObject object = null;
    	int n;
    	for(n = 0; n < array.length(); n++)
    	{
    	    try {
				object = array.getJSONObject(n);
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	    parent = new Parent();
            
            // Set values in parent class object
                    
                    try {
                    	parent.setName("" + object.getString("id"));
						parent.setText1(object.getString("docName"));
						parent.setText2(object.getString("docClinicAddress"));
	                    parent.setChildren(new ArrayList<Child>());
	                     
	                    // Create Child class object 
	                    final Child child = new Child();
	                      child.setName("" + n+1);
	                      child.setText1(object.getDouble("docExp")+" years of experaince");
	                       
	                      //Add Child class object to parent class object
	                      parent.getChildren().add(child);
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
                    
               list.add(parent);
    	}
    	parent = new Parent();
    	parent.setName("" + n+1);
        parent.setText1("Dr.Raghu");
        parent.setText2("Cardiologist");
        parent.setChildren(new ArrayList<Child>());
         
        final Child child = new Child();
         child.setName("" + n+1);
         child.setText1("15 years of experaince"); 
         parent.getChildren().add(child);
         list.add(parent);
        
        return list;
    }
     
     
    private void loadHosts(final ArrayList<Parent> newParents)
    {
        if (newParents == null)
            return;
         
        parents = newParents;
         
        // Check for ExpandableListAdapter object
        if (this.getExpandableListAdapter() == null)
        {
             //Create ExpandableListAdapter Object
            final MyExpandableListAdapter mAdapter = new MyExpandableListAdapter();
             
            // Set Adapter to ExpandableList Adapter
            this.setListAdapter(mAdapter);
        }
        else
        {
             // Refresh ExpandableListView data 
            ((MyExpandableListAdapter)getExpandableListAdapter()).notifyDataSetChanged();
        }   
    }
 
    /**
     * A Custom adapter to create Parent view (Used grouprow.xml) and Child View((Used childrow.xml).
     */
    private class MyExpandableListAdapter extends BaseExpandableListAdapter
    {
         
 
        private LayoutInflater inflater;
 
        public MyExpandableListAdapter()
        {
            // Create Layout Inflator
            inflater = LayoutInflater.from(SelectDoctorsActivity.this);
        }
     
        public boolean isNetworkAvailable() {
            ConnectivityManager connectivityManager 
                  = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
            return activeNetworkInfo != null && activeNetworkInfo.isConnected();
        }
        // This Function used to inflate parent rows view
         
        @Override
        public View getGroupView(int groupPosition, boolean isExpanded, 
                View convertView, ViewGroup parentView)
        {
            final Parent parent = parents.get(groupPosition);
            if(groupPosition==0)
            {
            	convertView = inflater.inflate(R.layout.activity_tab2, parentView, false);
            	((TextView) convertView.findViewById(R.id.texttab2)).setText("List of doctors belongs to "+bundle.getString("spec"));
            	return convertView;
            }
             if(groupPosition==getGroupCount()-1)
             {
            	 convertView = inflater.inflate(R.layout.sample, parentView, false); 
                 
                 Button b1 = (Button) convertView.findViewById(R.id.samplecancel);
                 Button b2 = (Button) convertView.findViewById(R.id.samplesubmit);
                 b1.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						finish();
						
					}
				});
                 b2.setOnClickListener(new OnClickListener() {
 					

					@Override
					
 					public void onClick(View v) {
 						Parent parent2;
 						boolean status=false;
 						String doc="";
 						for(int pos=0;pos<getGroupCount()-1;pos++)
 						{
 							parent2 = parents.get(pos);
 							if(parent2.isChecked())
 								status=true;
 						}
 						if(!status)
 						{
 							Toast.makeText(getApplicationContext(),"Please select a doctor" ,Toast.LENGTH_LONG).show();
 						}
 						else if(!isNetworkAvailable())
 						{
 							Toast.makeText(getApplicationContext(),"No internet connection" ,Toast.LENGTH_LONG).show();
 						}
 						else
 						{
 							String docName="";
 							for(int pos=0;pos<getGroupCount()-1;pos++)
 	 						{
 	 							parent2 = parents.get(pos);
 	 							if(parent2.isChecked())
 	 								{
 	 								doc=parent2.getName();
 	 								docName=parent2.getText1();
 	 								break;
 	 								}
 	 						}
 							bundle.putString("docname", docName);
 							bundle.putString("doc", doc);
 							bundle.putString("patid", "555");
 						
 							byte[] data1 = Base64.decode(bundle.getString("caseimg1"), Base64.DEFAULT);
 							byte[] data2 = Base64.decode(bundle.getString("caseimg2"), Base64.DEFAULT);
 							byte[] data3 = Base64.decode(bundle.getString("caseimg3"), Base64.DEFAULT);
 							try {
 					           File path = Environment.getExternalStoragePublicDirectory(
 					                  Environment.DIRECTORY_PICTURES);
 					           path.mkdirs();

 					            file1 = new File(path, "pic1.png");
 					           file2 = new File(path, "pic2.png");
 					          file3 = new File(path, "pic3.png");

 								FileOutputStream s1 = new FileOutputStream(file1);
 								s1.write(data1);
 								s1.close();
 								FileOutputStream s2 = new FileOutputStream(file2);
 								s2.write(data2);
 								s2.close();
 								FileOutputStream s3 = new FileOutputStream(file3);
 								s3.write(data3);
 								s3.close();
 								System.out.println("Sys1: After images reading");

							} catch (FileNotFoundException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
 							
 							
 							
 							
 					       RetrieveFeedTask r = new RetrieveFeedTask();
			               r.execute("hai",null);
 							Intent i = new Intent(getApplicationContext(),CaseSubmittedActivity.class);
 							i.putExtras(bundle);
 			                startActivity(i);
 						}
 					}
 				});
                return convertView;
             }
            // Inflate grouprow.xml file for parent rows
            convertView = inflater.inflate(R.layout.activity_select_doctors, parentView, false); 
             
            // Get grouprow.xml file elements and set values
            String temp2 = parent.getText1();
            if(temp2.length()>20)
            {
            	temp2 = temp2.substring(0, 19);
            	temp2+="...";
            	parent.setText1(temp2);
            }
            ((TextView) convertView.findViewById(R.id.text1)).setText(parent.getText1());
            String temp = parent.getText2();
            if(temp.length()>24)
            {
            	temp = temp.substring(0, 23);
            	temp+="...";
            	parent.setText2(temp);
            }
            ((TextView) convertView.findViewById(R.id.text)).setText(parent.getText2());
            ImageView image=(ImageView)convertView.findViewById(R.id.image);
             
            image.setImageResource(
                getResources().getIdentifier(
                   "com.mediassure:drawable/img1",null,null));
                       
             
             
            // Get grouprow.xml file checkbox elements
            CheckBox checkbox = (CheckBox) convertView.findViewById(R.id.checkbox);
            checkbox.setChecked(parent.isChecked());
             
            // Set CheckUpdateListener for CheckBox (see below CheckUpdateListener class)
            checkbox.setOnCheckedChangeListener(new CheckUpdateListener(parent));
             
            return convertView;
        }
        
        // This Function used to inflate child rows view
        @Override
        public View getChildView(int groupPosition, int childPosition, boolean isLastChild, 
                View convertView, ViewGroup parentView)
        {
            final Parent parent = parents.get(groupPosition);
            final Child child = parent.getChildren().get(childPosition);
             
            // Inflate childrow.xml file for child rows
            convertView = inflater.inflate(R.layout.child_row, parentView, false);
             
            // Get childrow.xml file elements and set values
            ((TextView) convertView.findViewById(R.id.text1)).setText(child.getText1());
           /* ImageView image=(ImageView)convertView.findViewById(R.id.image);
            image.setImageResource(
               getResources().getIdentifier(
                  "com.mediassure:drawable/img"+parent.getName(),null,null));*/
             
            return convertView;
        }
 
         
        @Override
        public Object getChild(int groupPosition, int childPosition)
        {
            //Log.i("Childs", groupPosition+"=  getChild =="+childPosition);
            return parents.get(groupPosition).getChildren().get(childPosition);
        }
 
        //Call when child row clicked
        @Override
        public long getChildId(int groupPosition, int childPosition)
        {
            /****** When Child row clicked then this function call *******/
             
            //Log.i("Noise", "parent == "+groupPosition+"=  child : =="+childPosition);
            if( ChildClickStatus!=childPosition)
            {
               ChildClickStatus = childPosition;
                

            }  
             
            return childPosition;
        }
 
        @Override
        public int getChildrenCount(int groupPosition)
        {
            int size=0;
            if(parents.get(groupPosition).getChildren()!=null)
                size = parents.get(groupPosition).getChildren().size();
            return size;
        }
      
         
        @Override
        public Object getGroup(int groupPosition)
        {
            Log.i("Parent", groupPosition+"=  getGroup ");
             
            return parents.get(groupPosition);
        }
 
        @Override
        public int getGroupCount()
        {
            return parents.size();
        }
 
        //Call when parent row clicked
        @Override
        public long getGroupId(int groupPosition)
        {
            Log.i("Parent", groupPosition+"=  getGroupId "+ParentClickStatus);
             
            if(groupPosition==2 && ParentClickStatus!=groupPosition){
                 
                //Alert to user
/*                Toast.makeText(getApplicationContext(), "Parent :"+groupPosition , 
                        Toast.LENGTH_LONG).show();*/
            }
             
            ParentClickStatus=groupPosition;
            if(ParentClickStatus==0)
                ParentClickStatus=-1;
             
            return groupPosition;
        }
 
        @Override
        public void notifyDataSetChanged()
        {
            // Refresh List rows
            super.notifyDataSetChanged();
        }
 
        @Override
        public boolean isEmpty()
        {
            return ((parents == null) || parents.isEmpty());
        }
 
        @Override
        public boolean isChildSelectable(int groupPosition, int childPosition)
        {
            return true;
        }
 
        @Override
        public boolean hasStableIds()
        {
            return true;
        }
 
        @Override
        public boolean areAllItemsEnabled()
        {
            return true;
        }
         
         
         
        /******************* Checkbox Checked Change Listener ********************/
         
        private final class CheckUpdateListener implements OnCheckedChangeListener
        {
            private final Parent parent;
             
            private CheckUpdateListener(Parent parent)
            {
                this.parent = parent;
            }
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
            {
                Log.i("onCheckedChanged", "isChecked: "+isChecked);
                parent.setChecked(isChecked);
                 
                ((MyExpandableListAdapter)getExpandableListAdapter()).notifyDataSetChanged();
                 
                final Boolean checked = parent.isChecked();
                Toast.makeText(getApplicationContext(), 
                      parent.getText1() + " " + (checked ? STR_CHECKED : STR_UNCHECKED), 
                           Toast.LENGTH_SHORT).show();
            }
        }
        /***********************************************************************/
         
    }
}
class RetrieveFeedTask extends AsyncTask<String, Void, String> {
	
	HttpResponse response;
	BufferedReader reader=null;
	HttpResponse httpResponse;
    static InputStream is = null;
    HttpEntity httpEntity = null;
	DefaultHttpClient httpClient = new DefaultHttpClient();
	String resp=null;
	protected void onPreExecute() {
	      super.onPreExecute();
	   }
	
	@Override
	protected String doInBackground(String... arg0) {
		System.out.println("Sys2: Inside doBackground method");
		

		try
	    {
	        HttpClient client = new DefaultHttpClient();
	        HttpPost post = new HttpPost("http://docit.tcs.us-south.mybluemix.net/api/case/add");

	        MultipartEntity entityBuilder = new MultipartEntity();
	        entityBuilder.addPart("patientId", new StringBody(MainActivity.patid));
	        entityBuilder.addPart("doctorId", new StringBody(SelectDoctorsActivity.bundle.getString("doc")));
	        entityBuilder.addPart("caseName", new StringBody(SelectDoctorsActivity.bundle.getString("casename")));
	        entityBuilder.addPart("caseDesc", new StringBody(SelectDoctorsActivity.bundle.getString("casedesc")));
	        entityBuilder.addPart("file1", new FileBody(SelectDoctorsActivity.file1,"image/png"));
	        entityBuilder.addPart("file2", new FileBody(SelectDoctorsActivity.file2,"image/png"));
	        entityBuilder.addPart("file3", new FileBody(SelectDoctorsActivity.file3,"image/png"));
	        
	        post.setEntity(entityBuilder);

	        response = client.execute(post);
	        HttpEntity httpEntity = response.getEntity();

	        Log.v("result", EntityUtils.toString(httpEntity));
	    }
	    catch(Exception e)
	    {
	        e.printStackTrace();
	    }
		try {
			JSONObject myObject = new JSONObject(response.toString());
			JSONArray myArray = myObject.getJSONArray("result");
			resp=myArray.getString(0);
			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return resp;
	}
	protected void onProgressUpdate(Integer... progress) {
		//SelectDoctorsActivity.progressBar.setProgress(progress[0]);
    }

    protected void onPostExecute(Long result) {
    	//SelectDoctorsActivity.progressBar.setVisibility(View.GONE);
    }
}
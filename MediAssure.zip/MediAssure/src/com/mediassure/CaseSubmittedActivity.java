package com.mediassure;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class CaseSubmittedActivity extends Activity {
	private TextView tv1,tv4;
	private ImageView iv1,iv2,iv3;
	private Button ok;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_case_submitted);
		Bundle bundle=getIntent().getExtras();
		tv1 = (TextView) findViewById(R.id.textView1);
		tv4 = (TextView) findViewById(R.id.textView4);
		iv1= (ImageView) findViewById(R.id.imageView1);
		iv2= (ImageView) findViewById(R.id.imageView2);
		iv3= (ImageView) findViewById(R.id.imageView3);
		
		ok = (Button) findViewById(R.id.ok);
		tv1.setText(bundle.getString("casename"));
		tv4.setText("Doctor : "+bundle.getString("docname"));
		String img1,img2,img3;
		img1=bundle.getString("caseimg1");
		img2=bundle.getString("caseimg2");
		img3=bundle.getString("caseimg3");
		
		   byte [] encodeByte1=Base64.decode(img1,Base64.DEFAULT);
	       Bitmap bitmap1=BitmapFactory.decodeByteArray(encodeByte1, 0, encodeByte1.length);
	       iv1.setImageBitmap(bitmap1);
	       byte [] encodeByte2=Base64.decode(img2,Base64.DEFAULT);
	       Bitmap bitmap2=BitmapFactory.decodeByteArray(encodeByte2, 0, encodeByte2.length);
	       iv2.setImageBitmap(bitmap2);
	       byte [] encodeByte3=Base64.decode(img3,Base64.DEFAULT);
	       Bitmap bitmap3=BitmapFactory.decodeByteArray(encodeByte3, 0, encodeByte3.length);
	       iv3.setImageBitmap(bitmap3);
		ok.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent i = new Intent(getApplicationContext(),UserCreateCaseActivity.class);
				 startActivity(i);
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.case_submitted, menu);
		return true;
	}
    @Override
    public void onBackPressed() {
        // do nothing.
    }
}
